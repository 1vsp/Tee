# نشر منصة HYIP على Render

## خطوات النشر

### 1. تحضير المستودع على GitHub
```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/your-username/hyip-investment-platform.git
git push -u origin main
```

### 2. إنشاء قاعدة بيانات MySQL
- استخدم خدمة مثل:
  - **PlanetScale** (MySQL compatible)
  - **Aiven** (MySQL)
  - **AWS RDS**
  - **DigitalOcean Managed Database**

احصل على رابط الاتصال: `mysql://user:password@host:port/database`

### 3. إنشاء تطبيق على Render

1. اذهب إلى [render.com](https://render.com)
2. اضغط **New +** → **Web Service**
3. اختر **Deploy existing repository**
4. ربط حسابك على GitHub واختر المستودع

### 4. إعدادات البناء والتشغيل

**Build Command:**
```
npm install && npm run build
```

**Start Command:**
```
npm start
```

### 5. متغيرات البيئة (Environment Variables)

أضف المتغيرات التالية في Render:

```
DATABASE_URL=mysql://user:password@host:port/database
NODE_ENV=production
JWT_SECRET=your_jwt_secret_here
VITE_APP_ID=your_manus_app_id
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://manus.im/login
OWNER_OPEN_ID=your_owner_open_id
OWNER_NAME=Admin
BUILT_IN_FORGE_API_URL=https://api.manus.im/forge
BUILT_IN_FORGE_API_KEY=your_forge_api_key
VITE_FRONTEND_FORGE_API_URL=https://api.manus.im/forge
VITE_FRONTEND_FORGE_API_KEY=your_frontend_forge_api_key
VITE_ANALYTICS_ENDPOINT=https://analytics.manus.im
VITE_ANALYTICS_WEBSITE_ID=your_website_id
VITE_APP_TITLE=HYIP Investment Platform
VITE_APP_LOGO=https://your-logo-url.png
```

### 6. إعدادات إضافية

- **Instance Type**: Free (أو Starter حسب احتياجاتك)
- **Region**: اختر الأقرب لمستخدميك
- **Auto-deploy**: فعّل لتحديثات تلقائية من GitHub

### 7. إعدادات قاعدة البيانات

بعد النشر، قم بتشغيل الترحيل:

```bash
npm run db:push
```

أو من Render Shell:
```bash
pnpm drizzle-kit generate && pnpm drizzle-kit migrate
```

## ملاحظات مهمة

⚠️ **تحذيرات:**
- تأكد من أن `DATABASE_URL` صحيح
- استخدم كلمات مرور قوية للـ JWT_SECRET
- لا تشارك المتغيرات السرية علناً
- استخدم HTTPS فقط

## استكشاف الأخطاء

### الخطأ: "Database connection failed"
- تحقق من `DATABASE_URL`
- تأكد من أن قاعدة البيانات متاحة
- تحقق من جدار الحماية (Firewall)

### الخطأ: "Build failed"
- تحقق من السجلات في Render
- تأكد من أن جميع الحزم مثبتة
- تحقق من متطلبات Node.js

### الخطأ: "OAuth not working"
- تحقق من `VITE_APP_ID` و `OAUTH_SERVER_URL`
- تأكد من إضافة رابط Render في إعدادات Manus OAuth

## روابط مفيدة

- [Render Docs](https://render.com/docs)
- [Manus OAuth Setup](https://manus.im/docs/oauth)
- [PlanetScale MySQL](https://planetscale.com)

## الدعم

للمساعدة، تواصل مع:
- فريق Render: support@render.com
- فريق Manus: support@manus.im
