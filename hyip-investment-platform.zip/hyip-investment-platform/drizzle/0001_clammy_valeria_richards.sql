CREATE TABLE `daily_profits` (
	`id` int AUTO_INCREMENT NOT NULL,
	`investment_id` int NOT NULL,
	`user_id` int NOT NULL,
	`profit_amount` decimal(20,8) NOT NULL,
	`profit_date` timestamp NOT NULL,
	`transaction_id` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `daily_profits_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `deposit_requests` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`amount` decimal(20,8) NOT NULL,
	`currency` varchar(20) NOT NULL,
	`status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
	`payment_proof_url` text,
	`wallet_address` text,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `deposit_requests_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `investment_plans` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`daily_return_rate` decimal(5,2) NOT NULL,
	`duration_days` int NOT NULL,
	`min_investment` decimal(20,8) NOT NULL,
	`max_investment` decimal(20,8) NOT NULL,
	`is_active` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `investment_plans_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `investments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`plan_id` int NOT NULL,
	`amount` decimal(20,8) NOT NULL,
	`start_date` timestamp NOT NULL DEFAULT (now()),
	`end_date` timestamp NOT NULL,
	`status` enum('active','completed','cancelled') NOT NULL DEFAULT 'active',
	`total_profit_earned` decimal(20,8) NOT NULL DEFAULT '0',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `investments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `referral_commissions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`referrer_id` int NOT NULL,
	`referred_user_id` int NOT NULL,
	`investment_id` int,
	`commission_amount` decimal(20,8) NOT NULL,
	`commission_rate` decimal(5,2) NOT NULL,
	`status` enum('pending','earned','withdrawn') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `referral_commissions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `referrals` (
	`id` int AUTO_INCREMENT NOT NULL,
	`referrer_id` int NOT NULL,
	`referred_user_id` int NOT NULL,
	`referral_code` varchar(50) NOT NULL,
	`status` enum('pending','active','inactive') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `referrals_id` PRIMARY KEY(`id`),
	CONSTRAINT `referrals_referral_code_unique` UNIQUE(`referral_code`)
);
--> statement-breakpoint
CREATE TABLE `transactions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`type` enum('deposit','withdrawal','investment','profit','refund') NOT NULL,
	`amount` decimal(20,8) NOT NULL,
	`currency` varchar(20),
	`status` enum('pending','completed','failed') NOT NULL DEFAULT 'pending',
	`description` text,
	`related_id` int,
	`related_type` varchar(50),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `transactions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `withdrawal_requests` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`amount` decimal(20,8) NOT NULL,
	`currency` varchar(20) NOT NULL,
	`status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
	`wallet_address` text NOT NULL,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `withdrawal_requests_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` ADD `balance` decimal(20,8) DEFAULT '0' NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `referral_code` varchar(50);--> statement-breakpoint
ALTER TABLE `users` ADD `is_blocked` boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD CONSTRAINT `users_referral_code_unique` UNIQUE(`referral_code`);--> statement-breakpoint
CREATE INDEX `daily_profit_investment_id_idx` ON `daily_profits` (`investment_id`);--> statement-breakpoint
CREATE INDEX `daily_profit_user_id_idx` ON `daily_profits` (`user_id`);--> statement-breakpoint
CREATE INDEX `deposit_user_id_idx` ON `deposit_requests` (`user_id`);--> statement-breakpoint
CREATE INDEX `deposit_status_idx` ON `deposit_requests` (`status`);--> statement-breakpoint
CREATE INDEX `user_id_idx` ON `investments` (`user_id`);--> statement-breakpoint
CREATE INDEX `plan_id_idx` ON `investments` (`plan_id`);--> statement-breakpoint
CREATE INDEX `commission_referrer_id_idx` ON `referral_commissions` (`referrer_id`);--> statement-breakpoint
CREATE INDEX `commission_referred_user_id_idx` ON `referral_commissions` (`referred_user_id`);--> statement-breakpoint
CREATE INDEX `referrer_id_idx` ON `referrals` (`referrer_id`);--> statement-breakpoint
CREATE INDEX `referred_user_id_idx` ON `referrals` (`referred_user_id`);--> statement-breakpoint
CREATE INDEX `transaction_user_id_idx` ON `transactions` (`user_id`);--> statement-breakpoint
CREATE INDEX `transaction_type_idx` ON `transactions` (`type`);--> statement-breakpoint
CREATE INDEX `withdrawal_user_id_idx` ON `withdrawal_requests` (`user_id`);--> statement-breakpoint
CREATE INDEX `withdrawal_status_idx` ON `withdrawal_requests` (`status`);--> statement-breakpoint
CREATE INDEX `referral_code_idx` ON `users` (`referral_code`);