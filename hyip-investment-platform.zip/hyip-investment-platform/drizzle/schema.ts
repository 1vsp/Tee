import { decimal, int, mysqlEnum, mysqlTable, text, timestamp, varchar, boolean, index } from "drizzle-orm/mysql-core";
import { relations } from "drizzle-orm";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
/**
 * Update users table to include balance and referral code
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
  balance: decimal("balance", { precision: 20, scale: 8 }).default("0").notNull(),
  referralCode: varchar("referral_code", { length: 50 }).unique(),
  isBlocked: boolean("is_blocked").default(false).notNull(),
}, (table) => ({
  referralCodeIdx: index("referral_code_idx").on(table.referralCode),
}));

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Investment Plans - تعريف خطط الاستثمار
 */
export const investmentPlans = mysqlTable("investment_plans", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  dailyReturnRate: decimal("daily_return_rate", { precision: 5, scale: 2 }).notNull(), // e.g., 2.50 for 2.5%
  durationDays: int("duration_days").notNull(),
  minInvestment: decimal("min_investment", { precision: 20, scale: 8 }).notNull(),
  maxInvestment: decimal("max_investment", { precision: 20, scale: 8 }).notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type InvestmentPlan = typeof investmentPlans.$inferSelect;
export type InsertInvestmentPlan = typeof investmentPlans.$inferInsert;

/**
 * Active Investments - الاستثمارات النشطة
 */
export const investments = mysqlTable("investments", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull(),
  planId: int("plan_id").notNull(),
  amount: decimal("amount", { precision: 20, scale: 8 }).notNull(),
  startDate: timestamp("start_date").defaultNow().notNull(),
  endDate: timestamp("end_date").notNull(),
  status: mysqlEnum("status", ["active", "completed", "cancelled"]).default("active").notNull(),
  totalProfitEarned: decimal("total_profit_earned", { precision: 20, scale: 8 }).default("0").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  userIdIdx: index("user_id_idx").on(table.userId),
  planIdIdx: index("plan_id_idx").on(table.planId),
}));

export type Investment = typeof investments.$inferSelect;
export type InsertInvestment = typeof investments.$inferInsert;

/**
 * Deposit Requests - طلبات الإيداع
 */
export const depositRequests = mysqlTable("deposit_requests", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull(),
  amount: decimal("amount", { precision: 20, scale: 8 }).notNull(),
  currency: varchar("currency", { length: 20 }).notNull(), // BTC, ETH, USDT, LTC
  status: mysqlEnum("status", ["pending", "approved", "rejected"]).default("pending").notNull(),
  paymentProofUrl: text("payment_proof_url"),
  walletAddress: text("wallet_address"), // Platform's wallet address
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  userIdIdx: index("deposit_user_id_idx").on(table.userId),
  statusIdx: index("deposit_status_idx").on(table.status),
}));

export type DepositRequest = typeof depositRequests.$inferSelect;
export type InsertDepositRequest = typeof depositRequests.$inferInsert;

/**
 * Withdrawal Requests - طلبات السحب
 */
export const withdrawalRequests = mysqlTable("withdrawal_requests", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull(),
  amount: decimal("amount", { precision: 20, scale: 8 }).notNull(),
  currency: varchar("currency", { length: 20 }).notNull(),
  status: mysqlEnum("status", ["pending", "approved", "rejected"]).default("pending").notNull(),
  walletAddress: text("wallet_address").notNull(), // User's wallet address
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  userIdIdx: index("withdrawal_user_id_idx").on(table.userId),
  statusIdx: index("withdrawal_status_idx").on(table.status),
}));

export type WithdrawalRequest = typeof withdrawalRequests.$inferSelect;
export type InsertWithdrawalRequest = typeof withdrawalRequests.$inferInsert;

/**
 * Transactions - سجل المعاملات
 */
export const transactions = mysqlTable("transactions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull(),
  type: mysqlEnum("type", ["deposit", "withdrawal", "investment", "profit", "refund"]).notNull(),
  amount: decimal("amount", { precision: 20, scale: 8 }).notNull(),
  currency: varchar("currency", { length: 20 }),
  status: mysqlEnum("status", ["pending", "completed", "failed"]).default("pending").notNull(),
  description: text("description"),
  relatedId: int("related_id"), // ID of related deposit/withdrawal/investment
  relatedType: varchar("related_type", { length: 50 }), // deposit_request, withdrawal_request, investment
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  userIdIdx: index("transaction_user_id_idx").on(table.userId),
  typeIdx: index("transaction_type_idx").on(table.type),
}));

export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = typeof transactions.$inferInsert;

/**
 * Referrals - نظام الإحالات
 */
export const referrals = mysqlTable("referrals", {
  id: int("id").autoincrement().primaryKey(),
  referrerId: int("referrer_id").notNull(), // User who referred
  referredUserId: int("referred_user_id").notNull(), // User who was referred
  referralCode: varchar("referral_code", { length: 50 }).notNull().unique(),
  status: mysqlEnum("status", ["pending", "active", "inactive"]).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  referrerIdIdx: index("referrer_id_idx").on(table.referrerId),
  referredUserIdIdx: index("referred_user_id_idx").on(table.referredUserId),
}));

export type Referral = typeof referrals.$inferSelect;
export type InsertReferral = typeof referrals.$inferInsert;

/**
 * Referral Commissions - عمولات الإحالة
 */
export const referralCommissions = mysqlTable("referral_commissions", {
  id: int("id").autoincrement().primaryKey(),
  referrerId: int("referrer_id").notNull(),
  referredUserId: int("referred_user_id").notNull(),
  investmentId: int("investment_id"),
  commissionAmount: decimal("commission_amount", { precision: 20, scale: 8 }).notNull(),
  commissionRate: decimal("commission_rate", { precision: 5, scale: 2 }).notNull(), // e.g., 10.00 for 10%
  status: mysqlEnum("status", ["pending", "earned", "withdrawn"]).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  referrerIdIdx: index("commission_referrer_id_idx").on(table.referrerId),
  referredUserIdIdx: index("commission_referred_user_id_idx").on(table.referredUserId),
}));

export type ReferralCommission = typeof referralCommissions.$inferSelect;
export type InsertReferralCommission = typeof referralCommissions.$inferInsert;

/**
 * Daily Profits - سجل الأرباح اليومية
 */
export const dailyProfits = mysqlTable("daily_profits", {
  id: int("id").autoincrement().primaryKey(),
  investmentId: int("investment_id").notNull(),
  userId: int("user_id").notNull(),
  profitAmount: decimal("profit_amount", { precision: 20, scale: 8 }).notNull(),
  profitDate: timestamp("profit_date").notNull(),
  transactionId: int("transaction_id"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  investmentIdIdx: index("daily_profit_investment_id_idx").on(table.investmentId),
  userIdIdx: index("daily_profit_user_id_idx").on(table.userId),
}));

export type DailyProfit = typeof dailyProfits.$inferSelect;
export type InsertDailyProfit = typeof dailyProfits.$inferInsert;

/**
 * Update users table to add balance and referral code
 */
export const usersRelations = relations(users, ({ many }) => ({
  investments: many(investments),
  depositRequests: many(depositRequests),
  withdrawalRequests: many(withdrawalRequests),
  transactions: many(transactions),
  referralsAsReferrer: many(referrals, { relationName: "referrer" }),
  referralsAsReferred: many(referrals, { relationName: "referred" }),
}));

export const investmentPlansRelations = relations(investmentPlans, ({ many }) => ({
  investments: many(investments),
}));

export const investmentsRelations = relations(investments, ({ one, many }) => ({
  user: one(users, { fields: [investments.userId], references: [users.id] }),
  plan: one(investmentPlans, { fields: [investments.planId], references: [investmentPlans.id] }),
  dailyProfits: many(dailyProfits),
}));

export const depositRequestsRelations = relations(depositRequests, ({ one }) => ({
  user: one(users, { fields: [depositRequests.userId], references: [users.id] }),
}));

export const withdrawalRequestsRelations = relations(withdrawalRequests, ({ one }) => ({
  user: one(users, { fields: [withdrawalRequests.userId], references: [users.id] }),
}));

export const transactionsRelations = relations(transactions, ({ one }) => ({
  user: one(users, { fields: [transactions.userId], references: [users.id] }),
}));

export const referralsRelations = relations(referrals, ({ one }) => ({
  referrer: one(users, { fields: [referrals.referrerId], references: [users.id], relationName: "referrer" }),
  referred: one(users, { fields: [referrals.referredUserId], references: [users.id], relationName: "referred" }),
}));

export const referralCommissionsRelations = relations(referralCommissions, ({ one }) => ({
  referrer: one(users, { fields: [referralCommissions.referrerId], references: [users.id] }),
  referred: one(users, { fields: [referralCommissions.referredUserId], references: [users.id] }),
}));

export const dailyProfitsRelations = relations(dailyProfits, ({ one }) => ({
  investment: one(investments, { fields: [dailyProfits.investmentId], references: [investments.id] }),
  user: one(users, { fields: [dailyProfits.userId], references: [users.id] }),
}));