import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import Home from "@/pages/Home";
import Dashboard from "@/pages/Dashboard";
import InvestmentPlans from "@/pages/InvestmentPlans";
import Deposit from "@/pages/Deposit";
import Withdraw from "@/pages/Withdraw";
import Transactions from "@/pages/Transactions";
import Referrals from "@/pages/Referrals";
import AdminDashboard from "@/pages/AdminDashboard";
import AdminUsers from "@/pages/AdminUsers";
import AdminDeposits from "@/pages/AdminDeposits";
import AdminWithdrawals from "@/pages/AdminWithdrawals";
import AdminPlans from "@/pages/AdminPlans";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";

function Router() {
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/dashboard"} component={Dashboard} />
      <Route path={"/dashboard/plans"} component={InvestmentPlans} />
      <Route path={"/dashboard/deposit"} component={Deposit} />
      <Route path={"/dashboard/withdraw"} component={Withdraw} />
      <Route path={"/dashboard/transactions"} component={Transactions} />
      <Route path={"/dashboard/referrals"} component={Referrals} />
      <Route path={"/admin/dashboard"} component={AdminDashboard} />
      <Route path={"/admin/users"} component={AdminUsers} />
      <Route path={"/admin/deposits"} component={AdminDeposits} />
      <Route path="{/admin/withdrawals}" component={AdminWithdrawals} />
      <Route path="{/admin/plans}" component={AdminPlans} />
      <Route path="{/404}" component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="dark"
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
