import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { LayoutDashboard, Users, DollarSign, TrendingUp, Settings, LogOut } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

interface AdminDashboardLayoutProps {
  children: React.ReactNode;
  currentPage?: string;
}

export default function AdminDashboardLayout({ children, currentPage = "dashboard" }: AdminDashboardLayoutProps) {
  const { user, isAuthenticated, logout } = useAuth();
  const [, setLocation] = useLocation();
  const logoutMutation = trpc.auth.logout.useMutation();

  useEffect(() => {
    if (!isAuthenticated) {
      setLocation("/");
      return;
    }
    
    if (user?.role !== "admin") {
      toast.error("Access denied: Admin only");
      setLocation("/dashboard");
    }
  }, [isAuthenticated, user, setLocation]);

  if (!isAuthenticated || user?.role !== "admin") {
    return null;
  }

  const handleLogout = async () => {
    try {
      await logoutMutation.mutateAsync();
      logout();
      setLocation("/");
    } catch (error) {
      toast.error("Logout failed");
    }
  };

  const navItems = [
    { id: "dashboard", label: "الداشبورد", icon: LayoutDashboard, href: "/admin/dashboard" },
    { id: "users", label: "إدارة المستخدمين", icon: Users, href: "/admin/users" },
    { id: "deposits", label: "طلبات الإيداع", icon: DollarSign, href: "/admin/deposits" },
    { id: "withdrawals", label: "طلبات السحب", icon: TrendingUp, href: "/admin/withdrawals" },
    { id: "plans", label: "خطط الاستثمار", icon: Settings, href: "/admin/plans" },
    { id: "statistics", label: "الإحصائيات", icon: TrendingUp, href: "/admin/statistics" },
  ];

  return (
    <div className="flex h-screen bg-slate-900">
      {/* Sidebar */}
      <div className="w-64 bg-slate-800 border-l border-slate-700 flex flex-col">
        {/* Logo */}
        <div className="p-6 border-b border-slate-700">
          <h1 className="text-2xl font-bold text-white">HYIP Admin</h1>
          <p className="text-slate-400 text-sm mt-1">لوحة التحكم</p>
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto p-4 space-y-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentPage === item.id;
            return (
              <a
                key={item.id}
                href={item.href}
                className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                  isActive
                    ? "bg-blue-600 text-white"
                    : "text-slate-300 hover:bg-slate-700"
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="font-medium">{item.label}</span>
              </a>
            );
          })}
        </nav>

        {/* User Info & Logout */}
        <div className="border-t border-slate-700 p-4 space-y-3">
          <div className="bg-slate-700/50 p-3 rounded-lg">
            <p className="text-slate-400 text-xs">المسؤول</p>
            <p className="text-white font-semibold text-sm truncate">{user?.name || "Admin"}</p>
            <p className="text-slate-400 text-xs truncate">{user?.email}</p>
          </div>
          <Button
            onClick={handleLogout}
            className="w-full bg-red-600 hover:bg-red-700 text-white"
            disabled={logoutMutation.isPending}
          >
            <LogOut className="w-4 h-4 mr-2" />
            {logoutMutation.isPending ? "جاري..." : "تسجيل الخروج"}
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="bg-slate-800 border-b border-slate-700 px-8 py-4">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold text-white">
              {navItems.find(item => item.id === currentPage)?.label || "Dashboard"}
            </h2>
            <div className="text-slate-400 text-sm">
              {new Date().toLocaleDateString('ar-SA')}
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-auto bg-slate-900">
          <div className="p-8">
            {children}
          </div>
        </div>
      </div>
    </div>
  );
}
