import AdminDashboardLayout from "@/components/AdminDashboardLayout";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { toast } from "sonner";
import { Search, Edit2, Lock, Unlock, Trash2 } from "lucide-react";

export default function AdminUsers() {
  const [searchTerm, setSearchTerm] = useState("");
  const [editingId, setEditingId] = useState<number | null>(null);
  const [newBalance, setNewBalance] = useState("");

  const { data: users = [] } = trpc.admin.getUsers.useQuery();
  const updateBalanceMutation = trpc.user.updateBalance.useMutation();
  const blockUserMutation = trpc.user.blockUser.useMutation();

  const filteredUsers = users.filter(user =>
    user.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.email?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleUpdateBalance = async (userId: number) => {
    if (!newBalance) {
      toast.error("الرجاء إدخال المبلغ");
      return;
    }

    try {
      await updateBalanceMutation.mutateAsync({
        userId,
        newBalance,
      });
      toast.success("تم تحديث الرصيد بنجاح");
      setEditingId(null);
      setNewBalance("");
    } catch (error: any) {
      toast.error(error.message || "فشل تحديث الرصيد");
    }
  };

  const handleBlockUser = async (userId: number, isBlocked: boolean) => {
    try {
      await blockUserMutation.mutateAsync({
        userId,
        isBlocked: !isBlocked,
      });
      toast.success(!isBlocked ? "تم حظر المستخدم" : "تم تفعيل المستخدم");
    } catch (error: any) {
      toast.error(error.message || "فشل تحديث حالة المستخدم");
    }
  };

  return (
    <AdminDashboardLayout currentPage="users">
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">إدارة المستخدمين</h1>
          <p className="text-slate-400">إدارة حسابات المستخدمين والأرصدة</p>
        </div>

        {/* Search */}
        <Card className="bg-slate-800 border-slate-700 p-6">
          <div className="relative">
            <Search className="absolute right-4 top-3 w-5 h-5 text-slate-400" />
            <Input
              type="text"
              placeholder="ابحث عن مستخدم..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-slate-700 border-slate-600 text-white placeholder-slate-500 pr-10"
            />
          </div>
        </Card>

        {/* Users Table */}
        <Card className="bg-slate-800 border-slate-700 p-6 overflow-x-auto">
          {filteredUsers.length > 0 ? (
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-700">
                  <th className="text-right py-3 px-4 text-slate-300 font-semibold">المستخدم</th>
                  <th className="text-right py-3 px-4 text-slate-300 font-semibold">البريد الإلكتروني</th>
                  <th className="text-right py-3 px-4 text-slate-300 font-semibold">الرصيد</th>
                  <th className="text-right py-3 px-4 text-slate-300 font-semibold">الحالة</th>
                  <th className="text-right py-3 px-4 text-slate-300 font-semibold">الإجراءات</th>
                </tr>
              </thead>
              <tbody>
                {filteredUsers.map((user) => (
                  <tr key={user.id} className="border-b border-slate-700 hover:bg-slate-700/50 transition-colors">
                    <td className="py-3 px-4">
                      <p className="text-white font-semibold">{user.name || "بدون اسم"}</p>
                      <p className="text-slate-400 text-sm">#{user.id}</p>
                    </td>
                    <td className="py-3 px-4 text-slate-300">{user.email || "-"}</td>
                    <td className="py-3 px-4">
                      {editingId === user.id ? (
                        <div className="flex gap-2">
                          <Input
                            type="number"
                            value={newBalance}
                            onChange={(e) => setNewBalance(e.target.value)}
                            className="bg-slate-600 border-slate-500 text-white w-24"
                            placeholder="0.00"
                            step="0.01"
                          />
                          <Button
                            size="sm"
                            onClick={() => handleUpdateBalance(user.id)}
                            className="bg-green-600 hover:bg-green-700"
                            disabled={updateBalanceMutation.isPending}
                          >
                            حفظ
                          </Button>
                          <Button
                            size="sm"
                            onClick={() => setEditingId(null)}
                            className="bg-slate-600 hover:bg-slate-700"
                          >
                            إلغاء
                          </Button>
                        </div>
                      ) : (
                        <p className="text-white font-semibold">${user.balance || "0.00"}</p>
                      )}
                    </td>
                    <td className="py-3 px-4">
                      <span className={`px-3 py-1 rounded-full text-sm font-semibold ${
                        user.isBlocked
                          ? "bg-red-500/20 text-red-400"
                          : "bg-green-500/20 text-green-400"
                      }`}>
                        {user.isBlocked ? "محظور" : "نشط"}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          onClick={() => {
                            setEditingId(user.id);
                            setNewBalance(user.balance?.toString() || "");
                          }}
                          className="bg-blue-600 hover:bg-blue-700"
                        >
                          <Edit2 className="w-4 h-4" />
                        </Button>
                        <Button
                          size="sm"
                          onClick={() => handleBlockUser(user.id, user.isBlocked)}
                          className={user.isBlocked ? "bg-green-600 hover:bg-green-700" : "bg-red-600 hover:bg-red-700"}
                        >
                          {user.isBlocked ? <Unlock className="w-4 h-4" /> : <Lock className="w-4 h-4" />}
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <div className="text-center py-8">
              <p className="text-slate-400">لا توجد مستخدمين</p>
            </div>
          )}
        </Card>

        {/* Summary */}
        <Card className="bg-slate-800 border-slate-700 p-6">
          <h3 className="text-xl font-bold text-white mb-4">ملخص</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-slate-700/50 p-4 rounded-lg">
              <p className="text-slate-400 text-sm mb-2">إجمالي المستخدمين</p>
              <p className="text-2xl font-bold text-white">{users.length}</p>
            </div>
            <div className="bg-slate-700/50 p-4 rounded-lg">
              <p className="text-slate-400 text-sm mb-2">إجمالي المستخدمين النشطون</p>
              <p className="text-2xl font-bold text-green-400">
                {users.filter((u: any) => !u.isBlocked).length}
              </p>
            </div>
            <div className="bg-slate-700/50 p-4 rounded-lg">
              <p className="text-slate-400 text-sm mb-2">المستخدمون المحظورون</p>
              <p className="text-2xl font-bold text-red-400">
                {users.filter((u: any) => u.isBlocked).length}
              </p>
            </div>
          </div>
        </Card>
      </div>
    </AdminDashboardLayout>
  );
}
