import UserDashboardLayout from "@/components/UserDashboardLayout";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { toast } from "sonner";
import { Download, CheckCircle, Clock, XCircle } from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { useEffect } from "react";

export default function Withdraw() {
  const { isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const [amount, setAmount] = useState("");
  const [currency, setCurrency] = useState("BTC");
  const [walletAddress, setWalletAddress] = useState("");

  useEffect(() => {
    if (!isAuthenticated) {
      setLocation("/");
    }
  }, [isAuthenticated, setLocation]);

  const { data: userStats } = trpc.user.getStats.useQuery();
  const { data: requests = [] } = trpc.withdrawals.getUserRequests.useQuery();
  const withdrawMutation = trpc.withdrawals.create.useMutation();

  if (!isAuthenticated) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!amount || !walletAddress) {
      toast.error("الرجاء ملء جميع الحقول");
      return;
    }

    const withdrawAmount = parseFloat(amount);
    const balance = parseFloat(userStats?.balance?.toString() || "0");

    if (withdrawAmount > balance) {
      toast.error("الرصيد غير كافي");
      return;
    }

    try {
      await withdrawMutation.mutateAsync({
        amount,
        currency,
        walletAddress,
      });
      toast.success("تم تقديم طلب السحب بنجاح!");
      setAmount("");
      setCurrency("BTC");
      setWalletAddress("");
    } catch (error: any) {
      toast.error(error.message || "حدث خطأ في تقديم الطلب");
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "approved":
        return <CheckCircle className="w-5 h-5 text-green-400" />;
      case "pending":
        return <Clock className="w-5 h-5 text-yellow-400" />;
      case "rejected":
        return <XCircle className="w-5 h-5 text-red-400" />;
      default:
        return null;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case "approved":
        return "موافق عليه";
      case "pending":
        return "قيد الانتظار";
      case "rejected":
        return "مرفوض";
      default:
        return status;
    }
  };

  return (
    <UserDashboardLayout currentPage="withdraw">
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">سحب أموال</h1>
          <p className="text-slate-400">اسحب أرباحك وأموالك من حسابك</p>
        </div>

        {/* Balance Info */}
        <Card className="bg-gradient-to-r from-purple-600/20 to-purple-600/5 border-purple-500/30 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 mb-2">الرصيد المتاح للسحب</p>
              <p className="text-4xl font-bold text-white">${userStats?.balance || "0.00"}</p>
            </div>
            <Download className="w-12 h-12 text-purple-400 opacity-50" />
          </div>
        </Card>

        {/* Withdrawal Form */}
        <Card className="bg-slate-800 border-slate-700 p-6">
          <h3 className="text-xl font-bold text-white mb-6">نموذج السحب</h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="text-white text-sm font-semibold mb-2 block">المبلغ</label>
              <Input
                type="number"
                placeholder="أدخل المبلغ"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="bg-slate-700 border-slate-600 text-white placeholder-slate-500"
                step="0.01"
                min="0"
                max={userStats?.balance?.toString()}
              />
              <p className="text-slate-400 text-xs mt-2">
                الرصيد المتاح: ${userStats?.balance || "0.00"}
              </p>
            </div>

            <div>
              <label className="text-white text-sm font-semibold mb-2 block">العملة</label>
              <Select value={currency} onValueChange={setCurrency}>
                <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-700 border-slate-600">
                  <SelectItem value="BTC" className="text-white">Bitcoin (BTC)</SelectItem>
                  <SelectItem value="ETH" className="text-white">Ethereum (ETH)</SelectItem>
                  <SelectItem value="USDT" className="text-white">Tether (USDT)</SelectItem>
                  <SelectItem value="USD" className="text-white">US Dollar (USD)</SelectItem>
                  <SelectItem value="EUR" className="text-white">Euro (EUR)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-white text-sm font-semibold mb-2 block">عنوان المحفظة</label>
              <Input
                type="text"
                placeholder="أدخل عنوان محفظتك"
                value={walletAddress}
                onChange={(e) => setWalletAddress(e.target.value)}
                className="bg-slate-700 border-slate-600 text-white placeholder-slate-500"
              />
              <p className="text-slate-400 text-xs mt-2">
                تأكد من صحة عنوان المحفظة قبل التقديم
              </p>
            </div>

            <div className="bg-orange-500/10 border border-orange-500/30 p-4 rounded-lg">
              <p className="text-orange-400 text-sm">
                ⚠️ تحذير: تأكد من أن عنوان المحفظة صحيح. لا يمكن استرجاع الأموال المرسلة إلى عنوان خاطئ.
              </p>
            </div>

            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white font-semibold py-3"
              disabled={withdrawMutation.isPending || !userStats?.balance || parseFloat(userStats.balance.toString()) === 0}
            >
              {withdrawMutation.isPending ? "جاري التقديم..." : "تقديم طلب السحب"}
            </Button>
          </form>
        </Card>

        {/* Withdrawal Requests History */}
        <Card className="bg-slate-800 border-slate-700 p-6">
          <h3 className="text-xl font-bold text-white mb-6">سجل طلبات السحب</h3>
          {requests.length > 0 ? (
            <div className="space-y-3">
              {requests.map((request) => (
                <div key={request.id} className="bg-slate-700/50 p-4 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-3">
                      <Download className="w-5 h-5 text-purple-400" />
                      <div>
                        <p className="text-white font-semibold">{request.amount} {request.currency}</p>
                        <p className="text-slate-400 text-sm">طلب #{request.id}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {getStatusIcon(request.status)}
                      <span className="text-slate-300 text-sm">{getStatusText(request.status)}</span>
                    </div>
                  </div>
                  <p className="text-slate-400 text-xs mb-2">
                    {new Date(request.createdAt).toLocaleDateString('ar-SA')}
                  </p>
                  <p className="text-slate-400 text-xs">
                    المحفظة: <span className="font-mono text-slate-300">{request.walletAddress.substring(0, 20)}...</span>
                  </p>
                  {request.notes && (
                    <p className="text-yellow-400 text-sm mt-2">ملاحظات: {request.notes}</p>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <p className="text-slate-400">لا توجد طلبات سحب حالياً</p>
            </div>
          )}
        </Card>
      </div>
    </UserDashboardLayout>
  );
}
