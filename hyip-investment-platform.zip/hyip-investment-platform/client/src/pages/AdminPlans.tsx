import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { toast } from "sonner";
import { Loader2, Plus, Edit2, Trash2 } from "lucide-react";

export default function AdminPlans() {
  const { user } = useAuth();
  const [isOpen, setIsOpen] = useState(false);
  const [editingPlan, setEditingPlan] = useState<any>(null);
  const [formData, setFormData] = useState({
    name: "",
    dailyReturnRate: "",
    durationDays: "",
    minInvestment: "",
    maxInvestment: "",
  });

  const { data: plans, isLoading, refetch } = trpc.plans.getAll.useQuery();
  const createPlan = trpc.plans.create.useMutation();
  const updatePlan = trpc.plans.update.useMutation();
  const deletePlan = trpc.plans.delete.useMutation();

  if (!user || user.role !== "admin") {
    return <div className="p-6">Access Denied</div>;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.name || !formData.dailyReturnRate || !formData.durationDays) {
      toast.error("Please fill in all required fields");
      return;
    }

    try {
      if (editingPlan) {
        await updatePlan.mutateAsync({
          id: editingPlan.id,
          ...formData,
          dailyReturnRate: parseFloat(formData.dailyReturnRate),
          durationDays: parseInt(formData.durationDays),
          minInvestment: parseFloat(formData.minInvestment || "0"),
          maxInvestment: parseFloat(formData.maxInvestment || "999999"),
        });
        toast.success("Plan updated successfully");
      } else {
        await createPlan.mutateAsync({
          ...formData,
          dailyReturnRate: parseFloat(formData.dailyReturnRate),
          durationDays: parseInt(formData.durationDays),
          minInvestment: parseFloat(formData.minInvestment || "0"),
          maxInvestment: parseFloat(formData.maxInvestment || "999999"),
        });
        toast.success("Plan created successfully");
      }

      setFormData({
        name: "",
        dailyReturnRate: "",
        durationDays: "",
        minInvestment: "",
        maxInvestment: "",
      });
      setEditingPlan(null);
      setIsOpen(false);
      refetch();
    } catch (error) {
      toast.error("Error saving plan");
    }
  };

  const handleEdit = (plan: any) => {
    setEditingPlan(plan);
    setFormData({
      name: String(plan.name),
      dailyReturnRate: String(plan.dailyReturnRate),
      durationDays: String(plan.durationDays),
      minInvestment: String(plan.minInvestment),
      maxInvestment: String(plan.maxInvestment),
    });
    setIsOpen(true);
  };

  const handleDelete = async (id: number) => {
    if (confirm("Are you sure you want to delete this plan?")) {
      try {
        await deletePlan.mutateAsync({ id });
        toast.success("Plan deleted successfully");
        refetch();
      } catch (error) {
        toast.error("Error deleting plan");
      }
    }
  };

  const handleOpenChange = (open: boolean) => {
    if (!open) {
      setEditingPlan(null);
      setFormData({
        name: "",
        dailyReturnRate: "",
        durationDays: "",
        minInvestment: "",
        maxInvestment: "",
      });
    }
    setIsOpen(open);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Investment Plans Management</h1>
        <Dialog open={isOpen} onOpenChange={handleOpenChange}>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <Plus className="w-4 h-4" />
              Add New Plan
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>
                {editingPlan ? "Edit Plan" : "Create New Plan"}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="name">Plan Name *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) =>
                    setFormData({ ...formData, name: e.target.value })
                  }
                  placeholder="e.g., Premium Plan"
                />
              </div>

              <div>
                <Label htmlFor="dailyReturnRate">Daily Return Rate (%) *</Label>
                <Input
                  id="dailyReturnRate"
                  type="number"
                  step="0.01"
                  value={formData.dailyReturnRate}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      dailyReturnRate: e.target.value,
                    })
                  }
                  placeholder="e.g., 2.5"
                />
              </div>

              <div>
                <Label htmlFor="durationDays">Duration (Days) *</Label>
                <Input
                  id="durationDays"
                  type="number"
                  value={formData.durationDays}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      durationDays: e.target.value,
                    })
                  }
                  placeholder="e.g., 30"
                />
              </div>

              <div>
                <Label htmlFor="minInvestment">Minimum Investment</Label>
                <Input
                  id="minInvestment"
                  type="number"
                  step="0.01"
                  value={formData.minInvestment}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      minInvestment: e.target.value,
                    })
                  }
                  placeholder="e.g., 100"
                />
              </div>

              <div>
                <Label htmlFor="maxInvestment">Maximum Investment</Label>
                <Input
                  id="maxInvestment"
                  type="number"
                  step="0.01"
                  value={formData.maxInvestment}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      maxInvestment: e.target.value,
                    })
                  }
                  placeholder="e.g., 10000"
                />
              </div>

              <Button
                type="submit"
                className="w-full"
                disabled={
                  createPlan.isPending || updatePlan.isPending
                }
              >
                {createPlan.isPending || updatePlan.isPending ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Saving...
                  </>
                ) : (
                  "Save Plan"
                )}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>All Investment Plans</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center py-8">
              <Loader2 className="w-8 h-8 animate-spin" />
            </div>
          ) : plans && plans.length > 0 ? (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Daily Return</TableHead>
                    <TableHead>Duration</TableHead>
                    <TableHead>Min Investment</TableHead>
                    <TableHead>Max Investment</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {plans.map((plan: any) => (
                    <TableRow key={plan.id}>
                      <TableCell className="font-medium">{plan.name}</TableCell>
                      <TableCell>{plan.dailyReturnRate}%</TableCell>
                      <TableCell>{plan.durationDays} days</TableCell>
                      <TableCell>${plan.minInvestment}</TableCell>
                      <TableCell>${plan.maxInvestment}</TableCell>
                      <TableCell>
                        <span
                          className={`px-2 py-1 rounded text-sm ${
                            plan.isActive
                              ? "bg-green-100 text-green-800"
                              : "bg-gray-100 text-gray-800"
                          }`}
                        >
                          {plan.isActive ? "Active" : "Inactive"}
                        </span>
                      </TableCell>
                      <TableCell className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEdit(plan)}
                        >
                          <Edit2 className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => handleDelete(plan.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500">
              No investment plans found
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
