import UserDashboardLayout from "@/components/UserDashboardLayout";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { Share2, Copy, Users, TrendingUp, DollarSign } from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { useEffect, useState } from "react";
import { toast } from "sonner";

export default function Referrals() {
  const { isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const [referralLink, setReferralLink] = useState("");

  useEffect(() => {
    if (!isAuthenticated) {
      setLocation("/");
    }
  }, [isAuthenticated, setLocation]);

  const { data: referralCode } = trpc.referrals.getCode.useQuery();
  const { data: stats } = trpc.referrals.getStats.useQuery();
  const { data: referrals = [] } = trpc.referrals.getList.useQuery();

  useEffect(() => {
    if (referralCode?.code) {
      const link = `${window.location.origin}?ref=${referralCode.code}`;
      setReferralLink(link);
    }
  }, [referralCode]);

  if (!isAuthenticated) return null;

  const handleCopyLink = () => {
    if (referralLink) {
      navigator.clipboard.writeText(referralLink);
      toast.success("تم نسخ الرابط!");
    }
  };

  const handleCopyCode = () => {
    if (referralCode?.code) {
      navigator.clipboard.writeText(referralCode.code);
      toast.success("تم نسخ الكود!");
    }
  };

  return (
    <UserDashboardLayout currentPage="referrals">
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">برنامج الإحالات</h1>
          <p className="text-slate-400">احصل على عمولات من خلال إحالة أصدقائك</p>
        </div>

        {/* Referral Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="bg-gradient-to-br from-blue-600/20 to-blue-600/5 border-blue-500/30 p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-slate-400 font-semibold">إجمالي الإحالات</h3>
              <Users className="w-5 h-5 text-blue-400" />
            </div>
            <p className="text-3xl font-bold text-white">{stats?.totalReferrals || 0}</p>
            <p className="text-sm text-slate-400 mt-2">عدد الأشخاص الذين أحلتهم</p>
          </Card>

          <Card className="bg-gradient-to-br from-green-600/20 to-green-600/5 border-green-500/30 p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-slate-400 font-semibold">الإحالات النشطة</h3>
              <TrendingUp className="w-5 h-5 text-green-400" />
            </div>
            <p className="text-3xl font-bold text-white">{stats?.activeReferrals || 0}</p>
            <p className="text-sm text-slate-400 mt-2">الإحالات التي تستثمر</p>
          </Card>

          <Card className="bg-gradient-to-br from-purple-600/20 to-purple-600/5 border-purple-500/30 p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-slate-400 font-semibold">إجمالي الأرباح</h3>
              <DollarSign className="w-5 h-5 text-purple-400" />
            </div>
            <p className="text-3xl font-bold text-white">${stats?.totalEarned || "0.00"}</p>
            <p className="text-sm text-slate-400 mt-2">إجمالي العمولات المكتسبة</p>
          </Card>

          <Card className="bg-gradient-to-br from-orange-600/20 to-orange-600/5 border-orange-500/30 p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-slate-400 font-semibold">أرباح معلقة</h3>
              <Share2 className="w-5 h-5 text-orange-400" />
            </div>
            <p className="text-3xl font-bold text-white">${stats?.pendingEarned || "0.00"}</p>
            <p className="text-sm text-slate-400 mt-2">عمولات قيد الانتظار</p>
          </Card>
        </div>

        {/* Referral Link */}
        <Card className="bg-slate-800 border-slate-700 p-6">
          <h3 className="text-xl font-bold text-white mb-4">رابط الإحالة الخاص بك</h3>
          <div className="space-y-4">
            <div className="bg-slate-700/50 p-4 rounded-lg">
              <p className="text-slate-400 text-sm mb-2">رابط الإحالة الكامل</p>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={referralLink}
                  readOnly
                  className="flex-1 bg-slate-600 border border-slate-500 text-white px-4 py-2 rounded-lg font-mono text-sm"
                />
                <Button
                  onClick={handleCopyLink}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  <Copy className="w-4 h-4" />
                </Button>
              </div>
            </div>

            <div className="bg-slate-700/50 p-4 rounded-lg">
              <p className="text-slate-400 text-sm mb-2">كود الإحالة</p>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={referralCode?.code || ""}
                  readOnly
                  className="flex-1 bg-slate-600 border border-slate-500 text-white px-4 py-2 rounded-lg font-mono text-sm"
                />
                <Button
                  onClick={handleCopyCode}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  <Copy className="w-4 h-4" />
                </Button>
              </div>
            </div>

            <div className="bg-blue-500/10 border border-blue-500/30 p-4 rounded-lg">
              <p className="text-blue-400 text-sm">
                💡 شارك الرابط مع أصدقائك واحصل على عمولة من كل استثمار يقومون به!
              </p>
            </div>
          </div>
        </Card>

        {/* How It Works */}
        <Card className="bg-slate-800 border-slate-700 p-6">
          <h3 className="text-xl font-bold text-white mb-4">كيف يعمل برنامج الإحالات</h3>
          <div className="space-y-3 text-slate-300">
            <div className="flex gap-4">
              <div className="flex-shrink-0 w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold">1</div>
              <div>
                <p className="font-semibold text-white">شارك الرابط</p>
                <p className="text-sm">شارك رابط الإحالة الخاص بك مع أصدقائك وعائلتك</p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="flex-shrink-0 w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold">2</div>
              <div>
                <p className="font-semibold text-white">يسجل الأصدقاء</p>
                <p className="text-sm">عندما يسجل صديقك من خلال رابطك، سيتم ربطه بحسابك</p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="flex-shrink-0 w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold">3</div>
              <div>
                <p className="font-semibold text-white">يستثمرون</p>
                <p className="text-sm">عندما يستثمر صديقك، تحصل أنت على عمولة من استثماره</p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="flex-shrink-0 w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold">4</div>
              <div>
                <p className="font-semibold text-white">احصل على أرباحك</p>
                <p className="text-sm">اسحب عمولاتك في أي وقت من قسم السحب</p>
              </div>
            </div>
          </div>
        </Card>

        {/* Referrals List */}
        <Card className="bg-slate-800 border-slate-700 p-6">
          <h3 className="text-xl font-bold text-white mb-6">قائمة الإحالات</h3>
          {referrals.length > 0 ? (
            <div className="space-y-3">
              {referrals.map((ref) => (
                <div key={ref.id} className="bg-slate-700/50 p-4 rounded-lg">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-white font-semibold">المستخدم #{ref.referredUserId}</p>
                      <p className="text-slate-400 text-sm">
                        تاريخ الإحالة: {new Date(ref.createdAt).toLocaleDateString('ar-SA')}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className={`font-semibold ${
                        ref.status === 'active' ? 'text-green-400' : 'text-slate-400'
                      }`}>
                        {ref.status === 'active' ? 'نشط' : 'غير نشط'}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <Users className="w-12 h-12 text-slate-400 mx-auto mb-4 opacity-50" />
              <p className="text-slate-400">لم تقم بإحالة أي شخص حتى الآن</p>
              <p className="text-slate-500 text-sm mt-2">شارك رابطك لبدء الحصول على عمولات</p>
            </div>
          )}
        </Card>
      </div>
    </UserDashboardLayout>
  );
}
