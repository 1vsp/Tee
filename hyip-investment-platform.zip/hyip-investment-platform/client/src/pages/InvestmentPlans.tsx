import UserDashboardLayout from "@/components/UserDashboardLayout";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { toast } from "sonner";
import { TrendingUp, AlertCircle } from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { useEffect } from "react";

export default function InvestmentPlans() {
  const { isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const [selectedPlan, setSelectedPlan] = useState<number | null>(null);
  const [investmentAmount, setInvestmentAmount] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  // Redirect if not authenticated
  useEffect(() => {
    if (!isAuthenticated) {
      setLocation("/");
    }
  }, [isAuthenticated, setLocation]);

  const { data: plans = [] } = trpc.plans.list.useQuery();
  const { data: userStats } = trpc.user.getStats.useQuery();
  const investMutation = trpc.investments.create.useMutation();

  if (!isAuthenticated) return null;

  const handleInvest = async () => {
    if (!selectedPlan || !investmentAmount) {
      toast.error("الرجاء ملء جميع الحقول");
      return;
    }

    const plan = plans.find(p => p.id === selectedPlan);
    if (!plan) {
      toast.error("الخطة غير موجودة");
      return;
    }

    const amount = parseFloat(investmentAmount);
    const minInv = parseFloat(plan.minInvestment.toString());
    const maxInv = parseFloat(plan.maxInvestment.toString());
    const balance = parseFloat(userStats?.balance?.toString() || "0");

    if (amount < minInv) {
      toast.error(`المبلغ أقل من الحد الأدنى: $${minInv}`);
      return;
    }

    if (amount > maxInv) {
      toast.error(`المبلغ يتجاوز الحد الأقصى: $${maxInv}`);
      return;
    }

    if (balance < amount) {
      toast.error("الرصيد غير كافي");
      return;
    }

    try {
      await investMutation.mutateAsync({
        planId: selectedPlan,
        amount: investmentAmount,
      });
      toast.success("تم الاستثمار بنجاح!");
      setIsDialogOpen(false);
      setInvestmentAmount("");
      setSelectedPlan(null);
    } catch (error: any) {
      toast.error(error.message || "حدث خطأ في الاستثمار");
    }
  };

  return (
    <UserDashboardLayout currentPage="plans">
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">خطط الاستثمار</h1>
          <p className="text-slate-400">اختر الخطة التي تناسب أهدافك الاستثمارية</p>
        </div>

        {/* Balance Info */}
        <Card className="bg-gradient-to-r from-blue-600/20 to-purple-600/20 border-blue-500/30 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 mb-2">رصيدك المتاح</p>
              <p className="text-4xl font-bold text-white">${userStats?.balance || "0.00"}</p>
            </div>
            <TrendingUp className="w-12 h-12 text-blue-400 opacity-50" />
          </div>
        </Card>

        {/* Plans Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {plans.map((plan) => (
            <Card key={plan.id} className="bg-slate-800 border-slate-700 overflow-hidden hover:border-blue-500 transition-colors flex flex-col">
              <div className="bg-gradient-to-r from-blue-500/10 to-purple-600/10 p-6 border-b border-slate-700">
                <h3 className="text-2xl font-bold text-white mb-2">{plan.name}</h3>
                <div className="flex items-baseline gap-2">
                  <span className="text-4xl font-bold text-blue-400">{plan.dailyReturnRate}%</span>
                  <span className="text-slate-400">يومياً</span>
                </div>
              </div>

              <div className="p-6 space-y-4 flex-1">
                <div className="space-y-3">
                  <div className="flex justify-between text-slate-300">
                    <span>المدة:</span>
                    <span className="font-semibold">{plan.durationDays} يوم</span>
                  </div>
                  <div className="flex justify-between text-slate-300">
                    <span>الحد الأدنى:</span>
                    <span className="font-semibold">${plan.minInvestment}</span>
                  </div>
                  <div className="flex justify-between text-slate-300">
                    <span>الحد الأقصى:</span>
                    <span className="font-semibold">${plan.maxInvestment}</span>
                  </div>
                  <div className="flex justify-between text-green-400 pt-3 border-t border-slate-700">
                    <span>العائد الإجمالي:</span>
                    <span className="font-semibold">
                      {(parseFloat(plan.dailyReturnRate.toString()) * plan.durationDays).toFixed(1)}%
                    </span>
                  </div>
                </div>

                <div className="pt-4 border-t border-slate-700">
                  <p className="text-sm text-slate-400 mb-4">
                    الأرباح المتوقعة: <span className="text-green-400 font-semibold">
                      ${(parseFloat(plan.minInvestment.toString()) * parseFloat(plan.dailyReturnRate.toString()) * plan.durationDays / 100).toFixed(2)} - ${(parseFloat(plan.maxInvestment.toString()) * parseFloat(plan.dailyReturnRate.toString()) * plan.durationDays / 100).toFixed(2)}
                    </span>
                  </p>

                  <Dialog open={isDialogOpen && selectedPlan === plan.id} onOpenChange={(open) => {
                    setIsDialogOpen(open);
                    if (!open) setSelectedPlan(null);
                  }}>
                    <DialogTrigger asChild>
                      <Button
                        className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700"
                        onClick={() => setSelectedPlan(plan.id)}
                      >
                        استثمر الآن
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="bg-slate-800 border-slate-700">
                      <DialogHeader>
                        <DialogTitle className="text-white">استثمر في {plan.name}</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div className="bg-slate-700/50 p-4 rounded-lg">
                          <p className="text-slate-400 text-sm mb-2">تفاصيل الخطة</p>
                          <div className="space-y-2 text-white">
                            <div className="flex justify-between">
                              <span>العائد اليومي:</span>
                              <span className="font-semibold text-blue-400">{plan.dailyReturnRate}%</span>
                            </div>
                            <div className="flex justify-between">
                              <span>المدة:</span>
                              <span className="font-semibold">{plan.durationDays} يوم</span>
                            </div>
                            <div className="flex justify-between">
                              <span>الحد الأدنى:</span>
                              <span className="font-semibold">${plan.minInvestment}</span>
                            </div>
                            <div className="flex justify-between">
                              <span>الحد الأقصى:</span>
                              <span className="font-semibold">${plan.maxInvestment}</span>
                            </div>
                          </div>
                        </div>

                        <div>
                          <label className="text-white text-sm font-semibold mb-2 block">المبلغ المراد استثماره</label>
                          <Input
                            type="number"
                            placeholder="أدخل المبلغ"
                            value={investmentAmount}
                            onChange={(e) => setInvestmentAmount(e.target.value)}
                            className="bg-slate-700 border-slate-600 text-white placeholder-slate-500"
                            min={plan.minInvestment}
                            max={plan.maxInvestment}
                          />
                          <p className="text-slate-400 text-xs mt-2">
                            الحد الأدنى: ${plan.minInvestment} | الحد الأقصى: ${plan.maxInvestment}
                          </p>
                        </div>

                        {investmentAmount && (
                          <div className="bg-green-500/10 border border-green-500/30 p-4 rounded-lg">
                            <p className="text-green-400 text-sm mb-2">الأرباح المتوقعة</p>
                            <p className="text-white font-bold text-lg">
                              ${(parseFloat(investmentAmount) * parseFloat(plan.dailyReturnRate.toString()) * plan.durationDays / 100).toFixed(2)}
                            </p>
                            <p className="text-slate-400 text-xs mt-1">
                              خلال {plan.durationDays} يوم
                            </p>
                          </div>
                        )}

                        <div className="flex gap-3">
                          <Button
                            className="flex-1 bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700"
                            onClick={handleInvest}
                            disabled={investMutation.isPending}
                          >
                            {investMutation.isPending ? "جاري الاستثمار..." : "تأكيد الاستثمار"}
                          </Button>
                          <Button
                            variant="outline"
                            className="flex-1 border-slate-600 text-white hover:bg-slate-700"
                            onClick={() => setIsDialogOpen(false)}
                          >
                            إلغاء
                          </Button>
                        </div>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              </div>
            </Card>
          ))}
        </div>

        {plans.length === 0 && (
          <Card className="bg-slate-800 border-slate-700 p-12 text-center">
            <AlertCircle className="w-12 h-12 text-slate-400 mx-auto mb-4" />
            <p className="text-slate-400">لا توجد خطط استثمارية متاحة حالياً</p>
          </Card>
        )}
      </div>
    </UserDashboardLayout>
  );
}
