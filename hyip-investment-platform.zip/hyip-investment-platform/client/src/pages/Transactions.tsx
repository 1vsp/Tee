import UserDashboardLayout from "@/components/UserDashboardLayout";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { History, ArrowUpRight, ArrowDownLeft, Zap } from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { useEffect, useState } from "react";

export default function Transactions() {
  const { isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const [filter, setFilter] = useState<string>("all");

  useEffect(() => {
    if (!isAuthenticated) {
      setLocation("/");
    }
  }, [isAuthenticated, setLocation]);

  const { data: transactions = [] } = trpc.transactions.getUser.useQuery();

  if (!isAuthenticated) return null;

  const filteredTransactions = filter === "all" 
    ? transactions 
    : transactions.filter(tx => tx.type === filter);

  const getIcon = (type: string) => {
    switch (type) {
      case "deposit":
        return <ArrowDownLeft className="w-5 h-5 text-green-400" />;
      case "withdrawal":
        return <ArrowUpRight className="w-5 h-5 text-red-400" />;
      case "investment":
        return <Zap className="w-5 h-5 text-blue-400" />;
      case "profit":
        return <ArrowDownLeft className="w-5 h-5 text-green-400" />;
      default:
        return <History className="w-5 h-5 text-slate-400" />;
    }
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case "deposit":
        return "إيداع";
      case "withdrawal":
        return "سحب";
      case "investment":
        return "استثمار";
      case "profit":
        return "أرباح";
      default:
        return type;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "text-green-400";
      case "pending":
        return "text-yellow-400";
      case "rejected":
        return "text-red-400";
      default:
        return "text-slate-400";
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "completed":
        return "مكتمل";
      case "pending":
        return "قيد الانتظار";
      case "rejected":
        return "مرفوض";
      default:
        return status;
    }
  };

  return (
    <UserDashboardLayout currentPage="transactions">
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">سجل المعاملات</h1>
          <p className="text-slate-400">عرض جميع معاملاتك والعمليات المالية</p>
        </div>

        {/* Filters */}
        <div className="flex gap-2 flex-wrap">
          <button
            onClick={() => setFilter("all")}
            className={`px-4 py-2 rounded-lg font-semibold transition-colors ${
              filter === "all"
                ? "bg-blue-600 text-white"
                : "bg-slate-700 text-slate-300 hover:bg-slate-600"
            }`}
          >
            الكل
          </button>
          <button
            onClick={() => setFilter("deposit")}
            className={`px-4 py-2 rounded-lg font-semibold transition-colors ${
              filter === "deposit"
                ? "bg-green-600 text-white"
                : "bg-slate-700 text-slate-300 hover:bg-slate-600"
            }`}
          >
            الإيداعات
          </button>
          <button
            onClick={() => setFilter("withdrawal")}
            className={`px-4 py-2 rounded-lg font-semibold transition-colors ${
              filter === "withdrawal"
                ? "bg-red-600 text-white"
                : "bg-slate-700 text-slate-300 hover:bg-slate-600"
            }`}
          >
            السحوبات
          </button>
          <button
            onClick={() => setFilter("investment")}
            className={`px-4 py-2 rounded-lg font-semibold transition-colors ${
              filter === "investment"
                ? "bg-blue-600 text-white"
                : "bg-slate-700 text-slate-300 hover:bg-slate-600"
            }`}
          >
            الاستثمارات
          </button>
          <button
            onClick={() => setFilter("profit")}
            className={`px-4 py-2 rounded-lg font-semibold transition-colors ${
              filter === "profit"
                ? "bg-purple-600 text-white"
                : "bg-slate-700 text-slate-300 hover:bg-slate-600"
            }`}
          >
            الأرباح
          </button>
        </div>

        {/* Transactions List */}
        <Card className="bg-slate-800 border-slate-700 p-6">
          {filteredTransactions.length > 0 ? (
            <div className="space-y-3">
              {filteredTransactions.map((tx) => (
                <div key={tx.id} className="bg-slate-700/50 p-4 rounded-lg hover:bg-slate-700 transition-colors">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="flex-shrink-0">
                        {getIcon(tx.type)}
                      </div>
                      <div>
                        <p className="text-white font-semibold capitalize">
                          {getTypeLabel(tx.type)}
                        </p>
                        <p className="text-slate-400 text-sm">{tx.description}</p>
                        <p className="text-slate-500 text-xs mt-1">
                          {new Date(tx.createdAt).toLocaleString('ar-SA')}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className={`text-lg font-bold ${
                        tx.type === 'deposit' || tx.type === 'profit'
                          ? 'text-green-400'
                          : 'text-red-400'
                      }`}>
                        {tx.type === 'deposit' || tx.type === 'profit' ? '+' : '-'}${tx.amount}
                      </p>
                      <p className={`text-sm capitalize ${getStatusColor(tx.status)}`}>
                        {getStatusLabel(tx.status)}
                      </p>
                      {tx.currency && (
                        <p className="text-slate-400 text-xs">{tx.currency}</p>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <History className="w-12 h-12 text-slate-400 mx-auto mb-4 opacity-50" />
              <p className="text-slate-400 text-lg">لا توجد معاملات</p>
              <p className="text-slate-500 text-sm mt-2">
                {filter === "all" 
                  ? "لم تقم بأي عملية حتى الآن"
                  : `لا توجد ${getTypeLabel(filter)} حالياً`
                }
              </p>
            </div>
          )}
        </Card>

        {/* Summary */}
        {filteredTransactions.length > 0 && (
          <Card className="bg-slate-800 border-slate-700 p-6">
            <h3 className="text-xl font-bold text-white mb-4">ملخص</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-slate-700/50 p-4 rounded-lg">
                <p className="text-slate-400 text-sm mb-2">إجمالي المعاملات</p>
                <p className="text-2xl font-bold text-white">{filteredTransactions.length}</p>
              </div>
              <div className="bg-slate-700/50 p-4 rounded-lg">
                <p className="text-slate-400 text-sm mb-2">المعاملات المكتملة</p>
                <p className="text-2xl font-bold text-green-400">
                  {filteredTransactions.filter(tx => tx.status === 'completed').length}
                </p>
              </div>
              <div className="bg-slate-700/50 p-4 rounded-lg">
                <p className="text-slate-400 text-sm mb-2">المعاملات المعلقة</p>
                <p className="text-2xl font-bold text-yellow-400">
                  {filteredTransactions.filter(tx => tx.status === 'pending').length}
                </p>
              </div>
            </div>
          </Card>
        )}
      </div>
    </UserDashboardLayout>
  );
}
