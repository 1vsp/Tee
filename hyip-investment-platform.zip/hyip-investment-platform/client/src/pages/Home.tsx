import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { getLoginUrl } from "@/const";
import { useLocation } from "wouter";
import { ArrowRight, TrendingUp, Shield, Zap, DollarSign, Users, Wallet } from "lucide-react";
import { useEffect, useState } from "react";

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const { data: plans = [] } = trpc.plans.list.useQuery();
  const [stats, setStats] = useState({ totalUsers: 0, activeInvestments: 0, totalDeposits: 0 });

  // Redirect authenticated users to dashboard
  useEffect(() => {
    if (isAuthenticated && user) {
      if (user.role === 'admin') {
        setLocation('/admin');
      } else {
        setLocation('/dashboard');
      }
    }
  }, [isAuthenticated, user, setLocation]);

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900">
      {/* Navigation */}
      <nav className="border-b border-slate-700 bg-slate-900/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-white">HYIP Investment</h1>
          </div>
          <div className="flex gap-3">
            {!isAuthenticated && (
              <>
                <Button variant="outline" asChild>
                  <a href={getLoginUrl()}>تسجيل الدخول</a>
                </Button>
                <Button className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700" asChild>
                  <a href={getLoginUrl()}>التسجيل</a>
                </Button>
              </>
            )}
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-5xl sm:text-6xl font-bold text-white mb-6 leading-tight">
              منصة استثمار آمنة وموثوقة
              <span className="block bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
                للعوائد العالية
              </span>
            </h2>
            <p className="text-xl text-slate-300 mb-8 max-w-2xl mx-auto">
              استثمر في خطط متنوعة واحصل على أرباح يومية مستقرة. منصة آمنة مع نظام إحالات مربح
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-lg" asChild>
                <a href={getLoginUrl()}>ابدأ الاستثمار الآن</a>
              </Button>
              <Button size="lg" variant="outline" className="text-lg border-slate-600 text-white hover:bg-slate-800">
                تعرف على المزيد
              </Button>
            </div>
          </div>

          {/* Statistics */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-20">
            <Card className="bg-slate-800/50 border-slate-700 p-6 text-center">
              <div className="flex justify-center mb-4">
                <Users className="w-8 h-8 text-blue-400" />
              </div>
              <div className="text-3xl font-bold text-white mb-2">{stats.totalUsers}+</div>
              <div className="text-slate-400">مستخدم نشط</div>
            </Card>
            <Card className="bg-slate-800/50 border-slate-700 p-6 text-center">
              <div className="flex justify-center mb-4">
                <Wallet className="w-8 h-8 text-purple-400" />
              </div>
              <div className="text-3xl font-bold text-white mb-2">{stats.activeInvestments}+</div>
              <div className="text-slate-400">استثمار نشط</div>
            </Card>
            <Card className="bg-slate-800/50 border-slate-700 p-6 text-center">
              <div className="flex justify-center mb-4">
                <DollarSign className="w-8 h-8 text-green-400" />
              </div>
              <div className="text-3xl font-bold text-white mb-2">${stats.totalDeposits}M+</div>
              <div className="text-slate-400">إجمالي الإيداعات</div>
            </Card>
          </div>
        </div>
      </section>

      {/* Investment Plans Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-slate-800/30">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h3 className="text-4xl font-bold text-white mb-4">خطط الاستثمار المتاحة</h3>
            <p className="text-xl text-slate-400">اختر الخطة التي تناسب أهدافك الاستثمارية</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {plans.map((plan) => (
              <Card key={plan.id} className="bg-slate-800 border-slate-700 overflow-hidden hover:border-blue-500 transition-colors">
                <div className="bg-gradient-to-r from-blue-500/10 to-purple-600/10 p-6 border-b border-slate-700">
                  <h4 className="text-2xl font-bold text-white mb-2">{plan.name}</h4>
                  <div className="flex items-baseline gap-2">
                    <span className="text-4xl font-bold text-blue-400">{plan.dailyReturnRate}%</span>
                    <span className="text-slate-400">يومياً</span>
                  </div>
                </div>
                <div className="p-6 space-y-4">
                  <div className="space-y-3">
                    <div className="flex justify-between text-slate-300">
                      <span>المدة:</span>
                      <span className="font-semibold">{plan.durationDays} يوم</span>
                    </div>
                    <div className="flex justify-between text-slate-300">
                      <span>الحد الأدنى:</span>
                      <span className="font-semibold">${plan.minInvestment}</span>
                    </div>
                    <div className="flex justify-between text-slate-300">
                      <span>الحد الأقصى:</span>
                      <span className="font-semibold">${plan.maxInvestment}</span>
                    </div>
                  </div>
                  <div className="pt-4 border-t border-slate-700">
                    <p className="text-sm text-slate-400 mb-4">
                      العائد الإجمالي: <span className="text-green-400 font-semibold">{(parseFloat(plan.dailyReturnRate.toString()) * plan.durationDays).toFixed(1)}%</span>
                    </p>
                    <Button className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700" asChild>
                      <a href={getLoginUrl()}>استثمر الآن</a>
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h3 className="text-4xl font-bold text-white mb-4">مميزات المنصة</h3>
            <p className="text-xl text-slate-400">كل ما تحتاجه لاستثمار آمن وناجح</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { icon: Shield, title: "آمن وموثوق", desc: "منصة محمية بأعلى معايير الأمان" },
              { icon: TrendingUp, title: "عوائد يومية", desc: "احصل على أرباحك كل يوم تلقائياً" },
              { icon: Zap, title: "سريع وسهل", desc: "واجهة بسيطة وسهلة الاستخدام" },
              { icon: DollarSign, title: "نظام إحالات", desc: "اكسب عمولات من إحالاتك" },
            ].map((feature, idx) => (
              <Card key={idx} className="bg-slate-800/50 border-slate-700 p-6 text-center hover:bg-slate-800 transition-colors">
                <div className="flex justify-center mb-4">
                  <feature.icon className="w-12 h-12 text-blue-400" />
                </div>
                <h4 className="text-xl font-bold text-white mb-2">{feature.title}</h4>
                <p className="text-slate-400">{feature.desc}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-blue-600/20 to-purple-600/20 border-y border-slate-700">
        <div className="max-w-3xl mx-auto text-center">
          <h3 className="text-4xl font-bold text-white mb-6">هل أنت مستعد للبدء؟</h3>
          <p className="text-xl text-slate-300 mb-8">
            انضم إلى آلاف المستثمرين الذين يحققون أرباحاً يومية من خلال منصتنا الموثوقة
          </p>
          <Button size="lg" className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-lg" asChild>
            <a href={getLoginUrl()}>
              ابدأ الآن <ArrowRight className="ml-2 w-5 h-5" />
            </a>
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 border-t border-slate-700 py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="text-white font-bold mb-4">عن المنصة</h4>
              <p className="text-slate-400 text-sm">منصة استثمار موثوقة توفر عوائد يومية آمنة</p>
            </div>
            <div>
              <h4 className="text-white font-bold mb-4">الروابط</h4>
              <ul className="space-y-2 text-slate-400 text-sm">
                <li><a href="#" className="hover:text-blue-400">الرئيسية</a></li>
                <li><a href="#" className="hover:text-blue-400">الخطط</a></li>
                <li><a href="#" className="hover:text-blue-400">التسجيل</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-bold mb-4">الدعم</h4>
              <ul className="space-y-2 text-slate-400 text-sm">
                <li><a href="#" className="hover:text-blue-400">الأسئلة الشائعة</a></li>
                <li><a href="#" className="hover:text-blue-400">التواصل</a></li>
                <li><a href="#" className="hover:text-blue-400">الشروط</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-bold mb-4">التواصل</h4>
              <ul className="space-y-2 text-slate-400 text-sm">
                <li>البريد: info@hyip.com</li>
                <li>الهاتف: +966 50 000 0000</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-slate-700 pt-8 text-center text-slate-400">
            <p>&copy; 2026 HYIP Investment Platform. جميع الحقوق محفوظة.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
