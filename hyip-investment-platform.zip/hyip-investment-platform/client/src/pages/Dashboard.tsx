import UserDashboardLayout from "@/components/UserDashboardLayout";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { Wallet, TrendingUp, DollarSign, History } from "lucide-react";
import { useLocation } from "wouter";
import { useEffect } from "react";
import { useAuth } from "@/_core/hooks/useAuth";

export default function Dashboard() {
  const { isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  
  // Redirect if not authenticated
  useEffect(() => {
    if (!isAuthenticated) {
      setLocation("/");
    }
  }, [isAuthenticated, setLocation]);

  const { data: stats } = trpc.user.getStats.useQuery();
  const { data: activeInvestments = [] } = trpc.investments.getActive.useQuery();
  const { data: transactions = [] } = trpc.transactions.getUser.useQuery();

  if (!isAuthenticated) return null;

  const recentTransactions = transactions.slice(0, 5);

  return (
    <UserDashboardLayout currentPage="dashboard">
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">لوحة المعلومات</h1>
          <p className="text-slate-400">مرحباً بك في منصة الاستثمار</p>
        </div>

        {/* Main Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* Balance Card */}
          <Card className="bg-gradient-to-br from-blue-600/20 to-blue-600/5 border-blue-500/30 p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-slate-400 font-semibold">الرصيد الحالي</h3>
              <Wallet className="w-5 h-5 text-blue-400" />
            </div>
            <p className="text-3xl font-bold text-white mb-2">
              ${stats?.balance || "0.00"}
            </p>
            <p className="text-sm text-slate-400">رصيدك المتاح للاستثمار</p>
          </Card>

          {/* Active Investments */}
          <Card className="bg-gradient-to-br from-purple-600/20 to-purple-600/5 border-purple-500/30 p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-slate-400 font-semibold">استثمارات نشطة</h3>
              <TrendingUp className="w-5 h-5 text-purple-400" />
            </div>
            <p className="text-3xl font-bold text-white mb-2">
              {stats?.activeInvestments || 0}
            </p>
            <p className="text-sm text-slate-400">عدد الاستثمارات الجارية</p>
          </Card>

          {/* Total Deposits */}
          <Card className="bg-gradient-to-br from-green-600/20 to-green-600/5 border-green-500/30 p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-slate-400 font-semibold">إجمالي الإيداعات</h3>
              <DollarSign className="w-5 h-5 text-green-400" />
            </div>
            <p className="text-3xl font-bold text-white mb-2">
              {stats?.totalDeposits || 0}
            </p>
            <p className="text-sm text-slate-400">عدد طلبات الإيداع المقبولة</p>
          </Card>

          {/* Referrals */}
          <Card className="bg-gradient-to-br from-orange-600/20 to-orange-600/5 border-orange-500/30 p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-slate-400 font-semibold">الإحالات</h3>
              <History className="w-5 h-5 text-orange-400" />
            </div>
            <p className="text-3xl font-bold text-white mb-2">
              {stats?.referralsCount || 0}
            </p>
            <p className="text-sm text-slate-400">عدد المستخدمين المحالين</p>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Button className="bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 h-12 text-base" asChild>
            <a href="/dashboard/plans">استثمر الآن</a>
          </Button>
          <Button className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 h-12 text-base" asChild>
            <a href="/dashboard/deposit">إيداع أموال</a>
          </Button>
          <Button className="bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 h-12 text-base" asChild>
            <a href="/dashboard/withdraw">سحب أموال</a>
          </Button>
        </div>

        {/* Active Investments Section */}
        <Card className="bg-slate-800 border-slate-700 p-6">
          <h3 className="text-xl font-bold text-white mb-4">الاستثمارات النشطة</h3>
          {activeInvestments.length > 0 ? (
            <div className="space-y-3">
              {activeInvestments.map((inv) => (
                <div key={inv.id} className="bg-slate-700/50 p-4 rounded-lg flex justify-between items-center">
                  <div>
                    <p className="text-white font-semibold">استثمار #{inv.id}</p>
                    <p className="text-slate-400 text-sm">المبلغ: ${inv.amount}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-green-400 font-semibold">${inv.totalProfitEarned} أرباح</p>
                    <p className="text-slate-400 text-sm">نشط</p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <p className="text-slate-400 mb-4">لا توجد استثمارات نشطة حالياً</p>
              <Button className="bg-blue-600 hover:bg-blue-700" asChild>
                <a href="/dashboard/plans">ابدأ الاستثمار</a>
              </Button>
            </div>
          )}
        </Card>

        {/* Recent Transactions */}
        <Card className="bg-slate-800 border-slate-700 p-6">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-xl font-bold text-white">آخر المعاملات</h3>
            <Button variant="ghost" size="sm" className="text-blue-400 hover:text-blue-300" asChild>
              <a href="/dashboard/transactions">عرض الكل</a>
            </Button>
          </div>
          {recentTransactions.length > 0 ? (
            <div className="space-y-3">
              {recentTransactions.map((tx) => (
                <div key={tx.id} className="bg-slate-700/50 p-4 rounded-lg flex justify-between items-center">
                  <div>
                    <p className="text-white font-semibold capitalize">{tx.type}</p>
                    <p className="text-slate-400 text-sm">{tx.description}</p>
                  </div>
                  <div className="text-right">
                    <p className={`font-semibold ${tx.type === 'deposit' || tx.type === 'profit' ? 'text-green-400' : 'text-red-400'}`}>
                      {tx.type === 'deposit' || tx.type === 'profit' ? '+' : '-'}${tx.amount}
                    </p>
                    <p className={`text-sm capitalize ${
                      tx.status === 'completed' ? 'text-green-400' :
                      tx.status === 'pending' ? 'text-yellow-400' :
                      'text-red-400'
                    }`}>
                      {tx.status}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-slate-400 text-center py-8">لا توجد معاملات حالياً</p>
          )}
        </Card>
      </div>
    </UserDashboardLayout>
  );
}
