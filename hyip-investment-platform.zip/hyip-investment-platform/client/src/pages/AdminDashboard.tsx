import AdminDashboardLayout from "@/components/AdminDashboardLayout";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Users, DollarSign, TrendingUp, AlertCircle, CheckCircle, Clock } from "lucide-react";

export default function AdminDashboard() {
  const { data: stats } = trpc.admin.getStats.useQuery();
  const { data: pendingDeposits = [] } = trpc.deposits.getPending.useQuery();
  const { data: pendingWithdrawals = [] } = trpc.withdrawals.getPending.useQuery();

  const StatCard = ({ label, value, icon: Icon, color }: any) => (
    <Card className={`bg-gradient-to-br from-${color}-600/20 to-${color}-600/5 border-${color}-500/30 p-6`}>
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-slate-400 font-semibold">{label}</h3>
        <Icon className={`w-5 h-5 text-${color}-400`} />
      </div>
      <p className="text-3xl font-bold text-white">{value}</p>
    </Card>
  );

  return (
    <AdminDashboardLayout currentPage="dashboard">
      <div className="space-y-6">
        {/* Main Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatCard
            label="إجمالي المستخدمين"
            value={stats?.totalUsers || 0}
            icon={Users}
            color="blue"
          />
          <StatCard
            label="إجمالي الإيداعات"
            value={`$${stats?.totalDeposits || "0.00"}`}
            icon={DollarSign}
            color="green"
          />
          <StatCard
            label="إجمالي السحوبات"
            value={`$${stats?.totalWithdrawals || "0.00"}`}
            icon={TrendingUp}
            color="purple"
          />
          <StatCard
            label="إجمالي الاستثمارات"
            value={`$${stats?.totalInvestments || "0.00"}`}
            icon={TrendingUp}
            color="orange"
          />
        </div>

        {/* Pending Requests */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Pending Deposits */}
          <Card className="bg-slate-800 border-slate-700 p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-bold text-white">طلبات إيداع معلقة</h3>
              <div className="bg-yellow-500/20 px-3 py-1 rounded-full">
                <span className="text-yellow-400 font-semibold">{pendingDeposits.length}</span>
              </div>
            </div>
            {pendingDeposits.length > 0 ? (
              <div className="space-y-3">
                {pendingDeposits.slice(0, 5).map((deposit) => (
                  <div key={deposit.id} className="bg-slate-700/50 p-3 rounded-lg flex items-center justify-between">
                    <div>
                      <p className="text-white font-semibold">المستخدم #{deposit.userId}</p>
                      <p className="text-slate-400 text-sm">{deposit.amount} {deposit.currency}</p>
                    </div>
                    <Clock className="w-5 h-5 text-yellow-400" />
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <CheckCircle className="w-12 h-12 text-green-400 mx-auto mb-2 opacity-50" />
                <p className="text-slate-400">لا توجد طلبات معلقة</p>
              </div>
            )}
            <a href="/admin/deposits" className="text-blue-400 hover:text-blue-300 text-sm mt-4 block">
              عرض الكل →
            </a>
          </Card>

          {/* Pending Withdrawals */}
          <Card className="bg-slate-800 border-slate-700 p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-bold text-white">طلبات سحب معلقة</h3>
              <div className="bg-yellow-500/20 px-3 py-1 rounded-full">
                <span className="text-yellow-400 font-semibold">{pendingWithdrawals.length}</span>
              </div>
            </div>
            {pendingWithdrawals.length > 0 ? (
              <div className="space-y-3">
                {pendingWithdrawals.slice(0, 5).map((withdrawal) => (
                  <div key={withdrawal.id} className="bg-slate-700/50 p-3 rounded-lg flex items-center justify-between">
                    <div>
                      <p className="text-white font-semibold">المستخدم #{withdrawal.userId}</p>
                      <p className="text-slate-400 text-sm">{withdrawal.amount} {withdrawal.currency}</p>
                    </div>
                    <Clock className="w-5 h-5 text-yellow-400" />
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <CheckCircle className="w-12 h-12 text-green-400 mx-auto mb-2 opacity-50" />
                <p className="text-slate-400">لا توجد طلبات معلقة</p>
              </div>
            )}
            <a href="/admin/withdrawals" className="text-blue-400 hover:text-blue-300 text-sm mt-4 block">
              عرض الكل →
            </a>
          </Card>
        </div>

        {/* Quick Actions */}
        <Card className="bg-slate-800 border-slate-700 p-6">
          <h3 className="text-xl font-bold text-white mb-4">الإجراءات السريعة</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <a href="/admin/users" className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-3 rounded-lg font-semibold transition-colors">
              إدارة المستخدمين
            </a>
            <a href="/admin/deposits" className="bg-green-600 hover:bg-green-700 text-white px-4 py-3 rounded-lg font-semibold transition-colors">
              مراجعة الإيداعات
            </a>
            <a href="/admin/plans" className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-3 rounded-lg font-semibold transition-colors">
              إدارة الخطط
            </a>
          </div>
        </Card>

        {/* System Health */}
        <Card className="bg-slate-800 border-slate-700 p-6">
          <h3 className="text-xl font-bold text-white mb-4">حالة النظام</h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-slate-700/50 rounded-lg">
              <span className="text-slate-300">قاعدة البيانات</span>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                <span className="text-green-400 text-sm">متصل</span>
              </div>
            </div>
            <div className="flex items-center justify-between p-3 bg-slate-700/50 rounded-lg">
              <span className="text-slate-300">خادم الويب</span>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                <span className="text-green-400 text-sm">يعمل</span>
              </div>
            </div>
            <div className="flex items-center justify-between p-3 bg-slate-700/50 rounded-lg">
              <span className="text-slate-300">نظام الإشعارات</span>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                <span className="text-green-400 text-sm">نشط</span>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </AdminDashboardLayout>
  );
}
