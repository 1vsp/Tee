import AdminDashboardLayout from "@/components/AdminDashboardLayout";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { toast } from "sonner";
import { CheckCircle, XCircle, Clock } from "lucide-react";

export default function AdminDeposits() {
  const [filter, setFilter] = useState<string>("all");
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [notes, setNotes] = useState("");

  const { data: deposits = [] } = trpc.deposits.getAll.useQuery();
  const approveMutation = trpc.deposits.approve.useMutation();
  const rejectMutation = trpc.deposits.reject.useMutation();

  const filteredDeposits = filter === "all"
    ? deposits
    : deposits.filter(d => d.status === filter);

  const handleApprove = async (id: number) => {
    try {
      await approveMutation.mutateAsync({
        depositId: id,
        notes: notes || undefined,
      });
      toast.success("تم الموافقة على الطلب");
      setSelectedId(null);
      setNotes("");
    } catch (error: any) {
      toast.error(error.message || "فشل الموافقة");
    }
  };

  const handleReject = async (id: number) => {
    try {
      await rejectMutation.mutateAsync({
        depositId: id,
        notes: notes || undefined,
      });
      toast.success("تم رفض الطلب");
      setSelectedId(null);
      setNotes("");
    } catch (error: any) {
      toast.error(error.message || "فشل الرفض");
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "approved":
        return <CheckCircle className="w-5 h-5 text-green-400" />;
      case "pending":
        return <Clock className="w-5 h-5 text-yellow-400" />;
      case "rejected":
        return <XCircle className="w-5 h-5 text-red-400" />;
      default:
        return null;
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "approved":
        return "موافق عليه";
      case "pending":
        return "قيد الانتظار";
      case "rejected":
        return "مرفوض";
      default:
        return status;
    }
  };

  return (
    <AdminDashboardLayout currentPage="deposits">
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">إدارة طلبات الإيداع</h1>
          <p className="text-slate-400">مراجعة والموافقة على طلبات الإيداع</p>
        </div>

        {/* Filters */}
        <div className="flex gap-2 flex-wrap">
          <button
            onClick={() => setFilter("all")}
            className={`px-4 py-2 rounded-lg font-semibold transition-colors ${
              filter === "all"
                ? "bg-blue-600 text-white"
                : "bg-slate-700 text-slate-300 hover:bg-slate-600"
            }`}
          >
            الكل ({deposits.length})
          </button>
          <button
            onClick={() => setFilter("pending")}
            className={`px-4 py-2 rounded-lg font-semibold transition-colors ${
              filter === "pending"
                ? "bg-yellow-600 text-white"
                : "bg-slate-700 text-slate-300 hover:bg-slate-600"
            }`}
          >
            قيد الانتظار ({deposits.filter(d => d.status === "pending").length})
          </button>
          <button
            onClick={() => setFilter("approved")}
            className={`px-4 py-2 rounded-lg font-semibold transition-colors ${
              filter === "approved"
                ? "bg-green-600 text-white"
                : "bg-slate-700 text-slate-300 hover:bg-slate-600"
            }`}
          >
            موافق عليه ({deposits.filter(d => d.status === "approved").length})
          </button>
          <button
            onClick={() => setFilter("rejected")}
            className={`px-4 py-2 rounded-lg font-semibold transition-colors ${
              filter === "rejected"
                ? "bg-red-600 text-white"
                : "bg-slate-700 text-slate-300 hover:bg-slate-600"
            }`}
          >
            مرفوض ({deposits.filter(d => d.status === "rejected").length})
          </button>
        </div>

        {/* Deposits List */}
        <div className="space-y-4">
          {filteredDeposits.length > 0 ? (
            filteredDeposits.map((deposit: any) => (
              <Card key={deposit.id} className="bg-slate-800 border-slate-700 p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-4">
                    {getStatusIcon(deposit.status)}
                    <div>
                      <p className="text-white font-semibold">طلب #{deposit.id}</p>
                      <p className="text-slate-400 text-sm">المستخدم #{deposit.userId}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold text-white">{deposit.amount}</p>
                    <p className="text-slate-400 text-sm">{deposit.currency}</p>
                  </div>
                </div>

                <div className="bg-slate-700/50 p-4 rounded-lg mb-4 space-y-2">
                  <div className="flex justify-between">
                    <span className="text-slate-400">التاريخ:</span>
                    <span className="text-white">{new Date(deposit.createdAt).toLocaleDateString('ar-SA')}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">الحالة:</span>
                    <span className="text-white">{getStatusLabel(deposit.status)}</span>
                  </div>
                  {deposit.paymentProofUrl && (
                    <div className="flex justify-between">
                      <span className="text-slate-400">إثبات الدفع:</span>
                      <a href={deposit.paymentProofUrl} target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:text-blue-300">
                        عرض الملف
                      </a>
                    </div>
                  )}
                  {deposit.notes && (
                    <div className="flex justify-between">
                      <span className="text-slate-400">ملاحظات:</span>
                      <span className="text-white">{deposit.notes}</span>
                    </div>
                  )}
                </div>

                {deposit.status === "pending" && (
                  <div className="space-y-3">
                    {selectedId === deposit.id ? (
                      <>
                        <Textarea
                          placeholder="أضف ملاحظات (اختياري)"
                          value={notes}
                          onChange={(e) => setNotes(e.target.value)}
                          className="bg-slate-700 border-slate-600 text-white placeholder-slate-500"
                          rows={3}
                        />
                        <div className="flex gap-3">
                          <Button
                            onClick={() => handleApprove(deposit.id)}
                            className="flex-1 bg-green-600 hover:bg-green-700 text-white"
                            disabled={approveMutation.isPending}
                          >
                            {approveMutation.isPending ? "جاري..." : "الموافقة"}
                          </Button>
                          <Button
                            onClick={() => handleReject(deposit.id)}
                            className="flex-1 bg-red-600 hover:bg-red-700 text-white"
                            disabled={rejectMutation.isPending}
                          >
                            {rejectMutation.isPending ? "جاري..." : "الرفض"}
                          </Button>
                          <Button
                            onClick={() => {
                              setSelectedId(null);
                              setNotes("");
                            }}
                            className="flex-1 bg-slate-600 hover:bg-slate-700 text-white"
                          >
                            إلغاء
                          </Button>
                        </div>
                      </>
                    ) : (
                      <Button
                        onClick={() => setSelectedId(deposit.id)}
                        className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                      >
                        مراجعة الطلب
                      </Button>
                    )}
                  </div>
                )}
              </Card>
            ))
          ) : (
            <div className="text-center py-12">
              <p className="text-slate-400 text-lg">لا توجد طلبات</p>
            </div>
          )}
        </div>
      </div>
    </AdminDashboardLayout>
  );
}
