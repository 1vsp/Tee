import UserDashboardLayout from "@/components/UserDashboardLayout";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { toast } from "sonner";
import { DollarSign, CheckCircle, Clock, XCircle } from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { useEffect } from "react";

export default function Deposit() {
  const { isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const [amount, setAmount] = useState("");
  const [currency, setCurrency] = useState("BTC");

  useEffect(() => {
    if (!isAuthenticated) {
      setLocation("/");
    }
  }, [isAuthenticated, setLocation]);

  const { data: requests = [] } = trpc.deposits.getUserRequests.useQuery();
  const depositMutation = trpc.deposits.create.useMutation();

  if (!isAuthenticated) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!amount) {
      toast.error("الرجاء إدخال المبلغ");
      return;
    }

    try {
      await depositMutation.mutateAsync({
        amount,
        currency,
        paymentProofUrl: undefined,
      });
      toast.success("تم تقديم طلب الإيداع بنجاح!");
      setAmount("");
      setCurrency("BTC");
    } catch (error: any) {
      toast.error(error.message || "حدث خطأ في تقديم الطلب");
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "approved":
        return <CheckCircle className="w-5 h-5 text-green-400" />;
      case "pending":
        return <Clock className="w-5 h-5 text-yellow-400" />;
      case "rejected":
        return <XCircle className="w-5 h-5 text-red-400" />;
      default:
        return null;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case "approved":
        return "موافق عليه";
      case "pending":
        return "قيد الانتظار";
      case "rejected":
        return "مرفوض";
      default:
        return status;
    }
  };

  return (
    <UserDashboardLayout currentPage="deposit">
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">إيداع أموال</h1>
          <p className="text-slate-400">أضف أموالاً إلى حسابك لبدء الاستثمار</p>
        </div>

        {/* Deposit Form */}
        <Card className="bg-slate-800 border-slate-700 p-6">
          <h3 className="text-xl font-bold text-white mb-6">نموذج الإيداع</h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="text-white text-sm font-semibold mb-2 block">المبلغ</label>
              <Input
                type="number"
                placeholder="أدخل المبلغ"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="bg-slate-700 border-slate-600 text-white placeholder-slate-500"
                step="0.01"
                min="0"
              />
            </div>

            <div>
              <label className="text-white text-sm font-semibold mb-2 block">العملة</label>
              <Select value={currency} onValueChange={setCurrency}>
                <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-700 border-slate-600">
                  <SelectItem value="BTC" className="text-white">Bitcoin (BTC)</SelectItem>
                  <SelectItem value="ETH" className="text-white">Ethereum (ETH)</SelectItem>
                  <SelectItem value="USDT" className="text-white">Tether (USDT)</SelectItem>
                  <SelectItem value="USD" className="text-white">US Dollar (USD)</SelectItem>
                  <SelectItem value="EUR" className="text-white">Euro (EUR)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="bg-blue-500/10 border border-blue-500/30 p-4 rounded-lg">
              <p className="text-blue-400 text-sm">
                📝 سيتم إرسال عنوان المحفظة لك بعد تقديم الطلب. يرجى إرسال المبلغ بدقة إلى العنوان المحدد.
              </p>
            </div>

            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white font-semibold py-3"
              disabled={depositMutation.isPending}
            >
              {depositMutation.isPending ? "جاري التقديم..." : "تقديم طلب الإيداع"}
            </Button>
          </form>
        </Card>

        {/* Deposit Requests History */}
        <Card className="bg-slate-800 border-slate-700 p-6">
          <h3 className="text-xl font-bold text-white mb-6">سجل طلبات الإيداع</h3>
          {requests.length > 0 ? (
            <div className="space-y-3">
              {requests.map((request) => (
                <div key={request.id} className="bg-slate-700/50 p-4 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-3">
                      <DollarSign className="w-5 h-5 text-blue-400" />
                      <div>
                        <p className="text-white font-semibold">{request.amount} {request.currency}</p>
                        <p className="text-slate-400 text-sm">طلب #{request.id}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {getStatusIcon(request.status)}
                      <span className="text-slate-300 text-sm">{getStatusText(request.status)}</span>
                    </div>
                  </div>
                  <p className="text-slate-400 text-xs">
                    {new Date(request.createdAt).toLocaleDateString('ar-SA')}
                  </p>
                  {request.notes && (
                    <p className="text-yellow-400 text-sm mt-2">ملاحظات: {request.notes}</p>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <p className="text-slate-400">لا توجد طلبات إيداع حالياً</p>
            </div>
          )}
        </Card>

        {/* Instructions */}
        <Card className="bg-slate-800 border-slate-700 p-6">
          <h3 className="text-xl font-bold text-white mb-4">خطوات الإيداع</h3>
          <div className="space-y-3 text-slate-300">
            <div className="flex gap-4">
              <div className="flex-shrink-0 w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold">1</div>
              <div>
                <p className="font-semibold text-white">أدخل المبلغ والعملة</p>
                <p className="text-sm">حدد المبلغ الذي تريد إيداعه والعملة المراد استخدامها</p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="flex-shrink-0 w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold">2</div>
              <div>
                <p className="font-semibold text-white">تقديم الطلب</p>
                <p className="text-sm">انقر على زر تقديم الطلب وسيتم إنشاء طلب إيداع جديد</p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="flex-shrink-0 w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold">3</div>
              <div>
                <p className="font-semibold text-white">استقبل عنوان المحفظة</p>
                <p className="text-sm">سيتم إرسال عنوان المحفظة الفريد لك عبر البريد الإلكتروني</p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="flex-shrink-0 w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold">4</div>
              <div>
                <p className="font-semibold text-white">أرسل الأموال</p>
                <p className="text-sm">أرسل المبلغ المحدد إلى عنوان المحفظة المرسل لك</p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="flex-shrink-0 w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold">5</div>
              <div>
                <p className="font-semibold text-white">انتظر الموافقة</p>
                <p className="text-sm">سيتم التحقق من الطلب والموافقة عليه خلال 24 ساعة</p>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </UserDashboardLayout>
  );
}
