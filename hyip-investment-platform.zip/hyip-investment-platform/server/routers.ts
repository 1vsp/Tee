import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import * as dbModule from "./db";
import { getDb } from "./db";
import { users } from "../drizzle/schema";
import { eq } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { nanoid } from "nanoid";
import { notifyOwner } from "./_core/notification";
import { createHeartbeatJob, listHeartbeatJobs } from "./_core/heartbeat";
import { parse as parseCookie } from "cookie";

// Helper to check if user is admin
const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== 'admin') {
    throw new TRPCError({ code: 'FORBIDDEN', message: 'Admin access required' });
  }
  return next({ ctx });
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // ============ User Management ============
  user: router({
    getProfile: protectedProcedure.query(async ({ ctx }) => {
      const user = await dbModule.getUserById(ctx.user.id);
      if (!user) throw new TRPCError({ code: 'NOT_FOUND' });
      return user;
    }),

    getStats: protectedProcedure.query(async ({ ctx }) => {
      return dbModule.getUserStats(ctx.user.id);
    }),

    updateBalance: adminProcedure
      .input(z.object({
        userId: z.number(),
        newBalance: z.string(),
      }))
      .mutation(async ({ input }) => {
        const user = await dbModule.getUserById(input.userId);
        if (!user) throw new TRPCError({ code: 'NOT_FOUND' });
        
        const dbInstance = await getDb();
        if (!dbInstance) throw new Error("Database not available");
        await dbInstance.update(users).set({ balance: input.newBalance }).where(eq(users.id, input.userId)) as any;
        
        return { success: true };
      }),

    blockUser: adminProcedure
      .input(z.object({ userId: z.number(), isBlocked: z.boolean() }))
      .mutation(async ({ input }) => {
        const user = await dbModule.getUserById(input.userId);
        if (!user) throw new TRPCError({ code: 'NOT_FOUND' });
        
        const dbInstance = await getDb();
        if (!dbInstance) throw new Error("Database not available");
        await dbInstance.update(users).set({ isBlocked: input.isBlocked }).where(eq(users.id, input.userId)) as any;
        
        return { success: true };
      }),
  }),

  // ============ Investment Plans ============
  plans: router({
    getAll: publicProcedure.query(async () => {
      return dbModule.getAllInvestmentPlans();
    }),

    list: publicProcedure.query(async () => {
      return dbModule.getAllInvestmentPlans();
    }),

    create: adminProcedure
      .input(z.object({
        name: z.string(),
        dailyReturnRate: z.number(),
        durationDays: z.number(),
        minInvestment: z.number(),
        maxInvestment: z.number(),
      }))
      .mutation(async ({ input }) => {
        return dbModule.createInvestmentPlan({
          name: input.name,
          dailyReturnRate: input.dailyReturnRate,
          durationDays: input.durationDays,
          minInvestment: input.minInvestment,
          maxInvestment: input.maxInvestment,
          isActive: true,
        });
      }),

    update: adminProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().optional(),
        dailyReturnRate: z.number().optional(),
        durationDays: z.number().optional(),
        minInvestment: z.number().optional(),
        maxInvestment: z.number().optional(),
        isActive: z.boolean().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return dbModule.updateInvestmentPlan(id, data);
      }),

    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        return dbModule.deleteInvestmentPlan(input.id);
      }),
  }),

  // ============ Investments ============
  investments: router({
    create: protectedProcedure
      .input(z.object({
        planId: z.number(),
        amount: z.string(),
      }))
      .mutation(async ({ ctx, input }) => {
        const user = await dbModule.getUserById(ctx.user.id);
        if (!user) throw new TRPCError({ code: 'NOT_FOUND' });
        if (user.isBlocked) throw new TRPCError({ code: 'FORBIDDEN', message: 'Account is blocked' });

        const plan = await dbModule.getInvestmentPlanById(input.planId);
        if (!plan) throw new TRPCError({ code: 'NOT_FOUND', message: 'Plan not found' });

        const amount = parseFloat(input.amount);
        const minInv = parseFloat(plan.minInvestment.toString());
        const maxInv = parseFloat(plan.maxInvestment.toString());
        const balance = parseFloat(user.balance.toString());

        if (amount < minInv) throw new TRPCError({ code: 'BAD_REQUEST', message: 'Amount below minimum' });
        if (amount > maxInv) throw new TRPCError({ code: 'BAD_REQUEST', message: 'Amount above maximum' });
        if (balance < amount) throw new TRPCError({ code: 'BAD_REQUEST', message: 'Insufficient balance' });

        const endDate = new Date();
        endDate.setDate(endDate.getDate() + plan.durationDays);

        const dbInstance = await getDb();
        if (!dbInstance) throw new Error("Database not available");

        // Create investment
        const investment = await dbModule.createInvestment({
          userId: ctx.user.id,
          planId: input.planId,
          amount: input.amount,
          startDate: new Date(),
          endDate,
          status: 'active',
          totalProfitEarned: '0',
        });

        // Deduct from balance
        const newBalance = (balance - amount).toString();
        await dbInstance.update(users).set({ balance: newBalance }).where(eq(users.id, ctx.user.id)) as any;

        // Create transaction
        await dbModule.createTransaction({
          userId: ctx.user.id,
          type: 'investment',
          amount: input.amount,
          currency: null,
          status: 'completed',
          description: `Investment in ${plan.name}`,
          relatedId: null,
          relatedType: 'investment',
        });

        return { success: true, investmentId: 0 };
      }),

    getActive: protectedProcedure.query(async ({ ctx }) => {
      return dbModule.getUserActiveInvestments(ctx.user.id);
    }),

    getHistory: protectedProcedure.query(async ({ ctx }) => {
      return dbModule.getUserInvestmentHistory(ctx.user.id);
    }),
  }),

  // ============ Deposits ============
  deposits: router({
    create: protectedProcedure
      .input(z.object({
        amount: z.string(),
        currency: z.string(),
        paymentProofUrl: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const user = await dbModule.getUserById(ctx.user.id);
        if (!user) throw new TRPCError({ code: 'NOT_FOUND' });
        if (user.isBlocked) throw new TRPCError({ code: 'FORBIDDEN', message: 'Account is blocked' });

        const deposit = await dbModule.createDepositRequest({
          userId: ctx.user.id,
          amount: input.amount,
          currency: input.currency,
          paymentProofUrl: input.paymentProofUrl || null,
          walletAddress: null,
          notes: null,
          status: 'pending',
        });

        // Notify admin
        await notifyOwner({
          title: 'New Deposit Request',
          content: `User ${user.name} submitted a deposit request for ${input.amount} ${input.currency}`,
        });

        return { success: true, depositId: 0 };
      }),

    getUserRequests: protectedProcedure.query(async ({ ctx }) => {
      return dbModule.getUserDepositRequests(ctx.user.id);
    }),

    getPending: adminProcedure.query(async () => {
      return dbModule.getPendingDepositRequests();
    }),

    getAll: adminProcedure.query(async () => {
      return dbModule.getAllDepositRequests();
    }),

    approve: adminProcedure
      .input(z.object({ depositId: z.number(), notes: z.string().optional() }))
      .mutation(async ({ input }) => {
        const deposit = await dbModule.getDepositRequestById(input.depositId);
        if (!deposit) throw new TRPCError({ code: 'NOT_FOUND' });

        const user = await dbModule.getUserById(deposit.userId);
        if (!user) throw new TRPCError({ code: 'NOT_FOUND' });

        const dbInstance = await getDb();
        if (!dbInstance) throw new Error("Database not available");

        // Update deposit status
        await dbModule.updateDepositRequest(input.depositId, { status: 'approved' });

        // Add to balance
        const newBalance = (parseFloat(user.balance.toString()) + parseFloat(deposit.amount.toString())).toString();
        await dbInstance.update(users).set({ balance: newBalance }).where(eq(users.id, user.id)) as any;

        // Create transaction
        await dbModule.createTransaction({
          userId: user.id,
          type: 'deposit',
          amount: deposit.amount,
          currency: deposit.currency,
          status: 'completed',
          description: `Deposit approved - ${deposit.currency}`,
          relatedId: input.depositId,
          relatedType: 'deposit_request',
        });

        // Notify user
        await notifyOwner({
          title: 'Deposit Approved',
          content: `Your deposit of ${deposit.amount} ${deposit.currency} has been approved`,
        });

        return { success: true };
      }),

    reject: adminProcedure
      .input(z.object({ depositId: z.number(), notes: z.string().optional() }))
      .mutation(async ({ input }) => {
        const deposit = await dbModule.getDepositRequestById(input.depositId);
        if (!deposit) throw new TRPCError({ code: 'NOT_FOUND' });

        await dbModule.updateDepositRequest(input.depositId, { status: 'rejected', notes: input.notes });

        return { success: true };
      }),
  }),

  // ============ Withdrawals ============
  withdrawals: router({
    create: protectedProcedure
      .input(z.object({
        amount: z.string(),
        currency: z.string(),
        walletAddress: z.string(),
      }))
      .mutation(async ({ ctx, input }) => {
        const user = await dbModule.getUserById(ctx.user.id);
        if (!user) throw new TRPCError({ code: 'NOT_FOUND' });
        if (user.isBlocked) throw new TRPCError({ code: 'FORBIDDEN', message: 'Account is blocked' });

        const amount = parseFloat(input.amount);
        const balance = parseFloat(user.balance.toString());

        if (balance < amount) throw new TRPCError({ code: 'BAD_REQUEST', message: 'Insufficient balance' });

        const withdrawal = await dbModule.createWithdrawalRequest({
          userId: ctx.user.id,
          amount: input.amount,
          currency: input.currency,
          walletAddress: input.walletAddress,
          status: 'pending',
          notes: null,
        }) as any;

        // Notify admin
        await notifyOwner({
          title: 'New Withdrawal Request',
          content: `User ${user.name} requested withdrawal of ${input.amount} ${input.currency}`,
        });

        return { success: true, withdrawalId: 0 };
      }),

    getUserRequests: protectedProcedure.query(async ({ ctx }) => {
      return dbModule.getUserWithdrawalRequests(ctx.user.id);
    }),

    getPending: adminProcedure.query(async () => {
      return dbModule.getPendingWithdrawalRequests();
    }),

    getAll: adminProcedure.query(async () => {
      return dbModule.getAllWithdrawalRequests();
    }),

    approve: adminProcedure
      .input(z.object({ withdrawalId: z.number(), notes: z.string().optional() }))
      .mutation(async ({ input }) => {
        const withdrawal = await dbModule.getWithdrawalRequestById(input.withdrawalId);
        if (!withdrawal) throw new TRPCError({ code: 'NOT_FOUND' });

        const user = await dbModule.getUserById(withdrawal.userId);
        if (!user) throw new TRPCError({ code: 'NOT_FOUND' });

        const dbInstance = await getDb();
        if (!dbInstance) throw new Error("Database not available");

        // Update withdrawal status
        await dbModule.updateWithdrawalRequest(input.withdrawalId, { status: 'approved' });

        // Deduct from balance
        const newBalance = (parseFloat(user.balance.toString()) - parseFloat(withdrawal.amount.toString())).toString();
        await dbInstance.update(users).set({ balance: newBalance }).where(eq(users.id, user.id)) as any;

        // Create transaction
        await dbModule.createTransaction({
          userId: user.id,
          type: 'withdrawal',
          amount: withdrawal.amount,
          currency: withdrawal.currency,
          status: 'completed',
          description: `Withdrawal approved - ${withdrawal.currency}`,
          relatedId: input.withdrawalId,
          relatedType: 'withdrawal_request',
        });

        return { success: true };
      }),

    reject: adminProcedure
      .input(z.object({ withdrawalId: z.number(), notes: z.string().optional() }))
      .mutation(async ({ input }) => {
        const withdrawal = await dbModule.getWithdrawalRequestById(input.withdrawalId);
        if (!withdrawal) throw new TRPCError({ code: 'NOT_FOUND' });

        await dbModule.updateWithdrawalRequest(input.withdrawalId, { status: 'rejected', notes: input.notes });

        return { success: true };
      }),
  }),

  // ============ Transactions ============
  transactions: router({
    getUser: protectedProcedure.query(async ({ ctx }) => {
      return dbModule.getUserTransactions(ctx.user.id);
    }),

    getAll: adminProcedure.query(async () => {
      return dbModule.getAllTransactions();
    }),
  }),

  // ============ Referrals ============
  referrals: router({
    getCode: protectedProcedure.query(async ({ ctx }) => {
      const user = await dbModule.getUserById(ctx.user.id);
      if (!user) throw new TRPCError({ code: 'NOT_FOUND' });
      
      if (!user.referralCode) {
        const code = nanoid(10);
        const dbInstance = await getDb();
        if (!dbInstance) throw new Error("Database not available");
        await dbInstance.update(users).set({ referralCode: code }).where(eq(users.id, ctx.user.id)) as any;
        return { code };
      }
      
      return { code: user.referralCode };
    }),

    getStats: protectedProcedure.query(async ({ ctx }) => {
      const referrals = await dbModule.getUserReferrals(ctx.user.id);
      const commissions = await dbModule.getUserReferralCommissions(ctx.user.id);
      
      const totalEarned = commissions.reduce((sum, c) => sum + parseFloat(c.commissionAmount.toString()), 0);
      const pendingEarned = commissions
        .filter(c => c.status === 'pending')
        .reduce((sum, c) => sum + parseFloat(c.commissionAmount.toString()), 0);
      
      return {
        totalReferrals: referrals.length,
        activeReferrals: referrals.filter(r => r.status === 'active').length,
        totalEarned: totalEarned.toString(),
        pendingEarned: pendingEarned.toString(),
      };
    }),

    getList: protectedProcedure.query(async ({ ctx }) => {
      return dbModule.getUserReferrals(ctx.user.id);
    }),
  }),

  // ============ Admin Dashboard ============
  admin: router({
    getStats: adminProcedure.query(async () => {
      return dbModule.getPlatformStats();
    }),

    getUsers: adminProcedure.query(async () => {
      const dbInstance = await getDb();
      if (!dbInstance) return [];
      return dbInstance.select().from(users);
    }),

    createDailyProfitsSchedule: adminProcedure
      .input(z.object({
        cron: z.string().default('0 0 0 * * *'),
      }))
      .mutation(async ({ input, ctx }) => {
        const sessionToken = parseCookie(ctx.req.headers.cookie ?? '')[COOKIE_NAME] ?? '';
        if (!sessionToken) throw new TRPCError({ code: 'UNAUTHORIZED' });

        const job = await createHeartbeatJob({
          name: 'daily-profits-calculation',
          cron: input.cron,
          path: '/api/scheduled/daily-profits',
          description: 'Daily profits calculation for all active investments',
        }, sessionToken);

        return { success: true, taskUid: job.taskUid, nextExecutionAt: job.nextExecutionAt };
      }),

    listSchedules: adminProcedure.query(async ({ ctx }) => {
      const sessionToken = parseCookie(ctx.req.headers.cookie ?? '')[COOKIE_NAME] ?? '';
      if (!sessionToken) throw new TRPCError({ code: 'UNAUTHORIZED' });

      const jobs = await listHeartbeatJobs(sessionToken);
      return jobs.jobs;
    }),
  }),
});

export type AppRouter = typeof appRouter;
