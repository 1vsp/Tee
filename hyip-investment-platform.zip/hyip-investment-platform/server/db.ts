import { eq, and, desc, lte, gte } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { 
  InsertUser, 
  users,
  investmentPlans,
  investments,
  depositRequests,
  withdrawalRequests,
  transactions,
  referrals,
  referralCommissions,
  dailyProfits,
  InvestmentPlan,
  Investment,
  DepositRequest,
  WithdrawalRequest,
  Transaction,
  Referral,
  ReferralCommission,
  DailyProfit
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ============ Investment Plans ============

export async function getAllInvestmentPlans() {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(investmentPlans).where(eq(investmentPlans.isActive, true));
}

export async function getInvestmentPlanById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(investmentPlans).where(eq(investmentPlans.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createInvestmentPlan(plan: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(investmentPlans).values(plan);
  return result;
}

export async function updateInvestmentPlan(id: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.update(investmentPlans).set(data).where(eq(investmentPlans.id, id));
}

export async function deleteInvestmentPlan(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.delete(investmentPlans).where(eq(investmentPlans.id, id));
}

// ============ Investments ============

export async function getUserActiveInvestments(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(investments)
    .where(and(eq(investments.userId, userId), eq(investments.status, 'active')));
}

export async function getUserInvestmentHistory(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(investments)
    .where(eq(investments.userId, userId))
    .orderBy(desc(investments.createdAt));
}

export async function createInvestment(investment: Omit<Investment, 'id' | 'createdAt' | 'updatedAt'>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.insert(investments).values(investment);
}

export async function updateInvestment(id: number, data: Partial<Omit<Investment, 'id' | 'createdAt' | 'updatedAt'>>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.update(investments).set(data).where(eq(investments.id, id));
}

export async function getInvestmentById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(investments).where(eq(investments.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getAllActiveInvestments() {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(investments).where(eq(investments.status, 'active'));
}

// ============ Deposit Requests ============

export async function createDepositRequest(request: Omit<DepositRequest, 'id' | 'createdAt' | 'updatedAt'>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.insert(depositRequests).values(request);
}

export async function getUserDepositRequests(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(depositRequests)
    .where(eq(depositRequests.userId, userId))
    .orderBy(desc(depositRequests.createdAt));
}

export async function getPendingDepositRequests() {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(depositRequests)
    .where(eq(depositRequests.status, 'pending'))
    .orderBy(desc(depositRequests.createdAt));
}

export async function getAllDepositRequests() {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(depositRequests)
    .orderBy(desc(depositRequests.createdAt));
}

export async function updateDepositRequest(id: number, data: Partial<Omit<DepositRequest, 'id' | 'createdAt' | 'updatedAt'>>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.update(depositRequests).set(data).where(eq(depositRequests.id, id));
}

export async function getDepositRequestById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(depositRequests).where(eq(depositRequests.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ============ Withdrawal Requests ============

export async function createWithdrawalRequest(request: Omit<WithdrawalRequest, 'id' | 'createdAt' | 'updatedAt'>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.insert(withdrawalRequests).values(request);
}

export async function getUserWithdrawalRequests(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(withdrawalRequests)
    .where(eq(withdrawalRequests.userId, userId))
    .orderBy(desc(withdrawalRequests.createdAt));
}

export async function getPendingWithdrawalRequests() {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(withdrawalRequests)
    .where(eq(withdrawalRequests.status, 'pending'))
    .orderBy(desc(withdrawalRequests.createdAt));
}

export async function getAllWithdrawalRequests() {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(withdrawalRequests)
    .orderBy(desc(withdrawalRequests.createdAt));
}

export async function updateWithdrawalRequest(id: number, data: Partial<Omit<WithdrawalRequest, 'id' | 'createdAt' | 'updatedAt'>>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.update(withdrawalRequests).set(data).where(eq(withdrawalRequests.id, id));
}

export async function getWithdrawalRequestById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(withdrawalRequests).where(eq(withdrawalRequests.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ============ Transactions ============

export async function createTransaction(transaction: Omit<Transaction, 'id' | 'createdAt' | 'updatedAt'>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.insert(transactions).values(transaction);
}

export async function getUserTransactions(userId: number, limit = 50) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(transactions)
    .where(eq(transactions.userId, userId))
    .orderBy(desc(transactions.createdAt))
    .limit(limit);
}

export async function getAllTransactions(limit = 100) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(transactions)
    .orderBy(desc(transactions.createdAt))
    .limit(limit);
}

// ============ Referrals ============

export async function createReferral(referral: Omit<Referral, 'id' | 'createdAt' | 'updatedAt'>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.insert(referrals).values(referral);
}

export async function getReferralByCode(code: string) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(referrals).where(eq(referrals.referralCode, code)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserReferrals(referrerId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(referrals).where(eq(referrals.referrerId, referrerId));
}

export async function updateReferral(id: number, data: Partial<Omit<Referral, 'id' | 'createdAt' | 'updatedAt'>>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.update(referrals).set(data).where(eq(referrals.id, id));
}

// ============ Referral Commissions ============

export async function createReferralCommission(commission: Omit<ReferralCommission, 'id' | 'createdAt' | 'updatedAt'>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.insert(referralCommissions).values(commission);
}

export async function getUserReferralCommissions(referrerId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(referralCommissions)
    .where(eq(referralCommissions.referrerId, referrerId))
    .orderBy(desc(referralCommissions.createdAt));
}

export async function getPendingReferralCommissions(referrerId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(referralCommissions)
    .where(and(
      eq(referralCommissions.referrerId, referrerId),
      eq(referralCommissions.status, 'pending')
    ));
}

// ============ Daily Profits ============

export async function createDailyProfit(profit: Omit<DailyProfit, 'id' | 'createdAt'>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.insert(dailyProfits).values(profit);
}

export async function getUserDailyProfits(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(dailyProfits)
    .where(eq(dailyProfits.userId, userId))
    .orderBy(desc(dailyProfits.profitDate));
}

export async function getDailyProfitsByDate(date: Date) {
  const db = await getDb();
  if (!db) return [];
  
  const startOfDay = new Date(date);
  startOfDay.setHours(0, 0, 0, 0);
  
  const endOfDay = new Date(date);
  endOfDay.setHours(23, 59, 59, 999);
  
  return db.select().from(dailyProfits)
    .where(and(
      gte(dailyProfits.profitDate, startOfDay),
      lte(dailyProfits.profitDate, endOfDay)
    ));
}

// ============ Statistics ============

export async function getPlatformStats() {
  const db = await getDb();
  if (!db) return null;
  
  const totalUsers = await db.select().from(users);
  const totalInvestments = await db.select().from(investments);
  const totalDeposits = await db.select().from(depositRequests).where(eq(depositRequests.status, 'approved'));
  const totalWithdrawals = await db.select().from(withdrawalRequests).where(eq(withdrawalRequests.status, 'approved'));
  
  return {
    totalUsers: totalUsers.length,
    totalInvestments: totalInvestments.length,
    activeInvestments: totalInvestments.filter(i => i.status === 'active').length,
    totalDeposits: totalDeposits.length,
    totalWithdrawals: totalWithdrawals.length,
  };
}

export async function getUserStats(userId: number) {
  const db = await getDb();
  if (!db) return null;
  
  const user = await getUserById(userId);
  if (!user) return null;
  
  const activeInvestments = await getUserActiveInvestments(userId);
  const totalDeposits = await db.select().from(depositRequests)
    .where(and(eq(depositRequests.userId, userId), eq(depositRequests.status, 'approved')));
  const totalWithdrawals = await db.select().from(withdrawalRequests)
    .where(and(eq(withdrawalRequests.userId, userId), eq(withdrawalRequests.status, 'approved')));
  const referrals = await getUserReferrals(userId);
  
  return {
    balance: user.balance,
    activeInvestments: activeInvestments.length,
    totalDeposits: totalDeposits.length,
    totalWithdrawals: totalWithdrawals.length,
    referralsCount: referrals.length,
  };
}
