import { describe, it, expect, beforeEach, vi } from "vitest";
import { calculateDailyProfits } from "./dailyProfits";
import * as db from "../db";

// Mock the database module
vi.mock("../db", () => ({
  getDb: vi.fn(),
}));

describe("calculateDailyProfits", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("should return success with 0 profits when no active investments", async () => {
    const mockDb = {
      select: vi.fn().mockReturnValue({
        from: vi.fn().mockReturnValue({
          where: vi.fn().mockResolvedValue([]),
        }),
      }),
    };

    vi.mocked(db.getDb).mockResolvedValue(mockDb as any);

    const result = await calculateDailyProfits();

    expect(result.success).toBe(true);
    expect(result.profitsCalculated).toBe(0);
  });

  it("should handle database not available error", async () => {
    vi.mocked(db.getDb).mockResolvedValue(null);

    await expect(calculateDailyProfits()).rejects.toThrow("Database not available");
  });


});
