import { getDb } from "../db";
import { investments, dailyProfits, users, transactions, investmentPlans } from "../../drizzle/schema";
import { desc } from "drizzle-orm";
import { eq, and, lte } from "drizzle-orm";

/**
 * Daily profits calculation job
 * Runs every day at 00:00 UTC to calculate and distribute daily profits
 * to all active investments
 */
export async function calculateDailyProfits() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  try {
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());

    // Get all active investments
    const activeInvestments = await db
      .select()
      .from(investments)
      .where(eq(investments.status, "active"));

    if (activeInvestments.length === 0) {
      return { success: true, profitsCalculated: 0 };
    }

    let profitsCalculated = 0;

    // Calculate profits for each investment
    for (const investment of activeInvestments) {
      // Check if profit already calculated for today (idempotency)
      const existingProfit = await db
        .select()
        .from(dailyProfits)
        .where(
          and(
            eq(dailyProfits.investmentId, investment.id),
            eq(dailyProfits.profitDate, today)
          )
        )
        .limit(1);

      if (existingProfit.length > 0) {
        console.log(`[Daily Profits] Skipping investment ${investment.id} - profit already calculated for today`);
        continue;
      }

      // Get the plan for this investment
      const planDb = await db
        .select()
        .from(investmentPlans)
        .where(eq(investmentPlans.id, investment.planId))
        .limit(1);
      if (planDb.length === 0) continue;
      
      const plan = planDb[0];
      const dailyRate = parseFloat(plan.dailyReturnRate.toString());
      const investmentAmount = parseFloat(investment.amount.toString());
      const dailyProfit = (investmentAmount * dailyRate) / 100;

      // Create daily profit record
      await db.insert(dailyProfits).values({
        investmentId: investment.id,
        userId: investment.userId,
        profitAmount: dailyProfit.toString(),
        profitDate: today,
        createdAt: now,
      });

      // Update user balance with profit
      const user = await db
        .select()
        .from(users)
        .where(eq(users.id, investment.userId))
        .limit(1);

      if (user.length > 0) {
        const currentBalance = parseFloat(user[0].balance.toString());
        const newBalance = (currentBalance + dailyProfit).toString();

        await db
          .update(users)
          .set({ balance: newBalance })
          .where(eq(users.id, investment.userId));
      }

      // Check if investment has ended
      if (investment.endDate && investment.endDate <= now) {
        await db
          .update(investments)
          .set({ status: 'completed' })
          .where(eq(investments.id, investment.id));
        console.log(`[Daily Profits] Investment ${investment.id} completed`);
      }

      profitsCalculated++;
    }

    return {
      success: true,
      profitsCalculated,
      timestamp: now.toISOString(),
    };
  } catch (error) {
    console.error("[Daily Profits] Error calculating profits:", error);
    throw error;
  }
}
